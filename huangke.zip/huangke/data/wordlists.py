"""Built-in wordlists and wordlist loading utilities."""

from pathlib import Path

_WORDLIST_DIR = Path(__file__).parent.parent / "wordlists"

BUILTIN_WORDLISTS = {
    "common": "common.txt",
    "sensitive": "sensitive.txt",
    "api": "api.txt",
    "ports": "ports.txt",
    "subdomains": "subdomains.txt",
    "subdomain": "subdomain.txt",
    "tech": "technology.txt",
    "vuln": "vulnerability.txt",
    "backup": "backup.txt",
    "admin": "admin.txt",
    "framework": "framework.txt",
}


def load_wordlist(name_or_path: str) -> list[str]:
    """Load a wordlist by name (builtin) or by file path."""
    if name_or_path in BUILTIN_WORDLISTS:
        path = _WORDLIST_DIR / BUILTIN_WORDLISTS[name_or_path]
    else:
        path = Path(name_or_path)

    if not path.exists():
        raise FileNotFoundError(f"Wordlist not found: {path}")

    entries = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                entries.append(line)
    return entries


def load_default_wordlist() -> list[str]:
    """Load the combined default wordlist (common + sensitive + api + tech + vuln + backup + admin)."""
    entries = []
    for name in ("common", "sensitive", "api", "tech", "vuln", "backup", "admin"):
        try:
            entries.extend(load_wordlist(name))
        except (FileNotFoundError, OSError):
            pass
    seen = set()
    result = []
    for e in entries:
        if e not in seen:
            seen.add(e)
            result.append(e)
    return result
