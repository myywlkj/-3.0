"""内容安全分析引擎 — 敏感信息检测 | 漏洞发现 | 安全配置检查"""

import re
from dataclasses import dataclass, field
from functools import lru_cache
from urllib.parse import urljoin

from ..core.engine import HTTPEngine, HttpResponse
from ..utils.risk import Severity, assess_content_finding


@dataclass
class ContentFinding:
    finding_type: str
    detail: str
    severity: Severity
    url: str
    context: str = ""


@dataclass
class AnalysisResult:
    url: str
    findings: list = field(default_factory=list)


# ── Pre-compiled regex patterns ──
SENSITIVE_REGEX = [
    (re.compile(r"(?:password|passwd|pwd|pass)\s*[=:]\s*['\"][^'\"]{4,}['\"]"), "硬编码密码", Severity.CRITICAL),
    (re.compile(r"(?:api[_-]?key|api[_-]?secret|access[_-]?key|secret[_-]?key|auth[_-]?token)\s*[=:]\s*['\"]([^'\"]{8,})['\"]"), "API 密钥泄露", Severity.CRITICAL),
    (re.compile(r"(?:-----BEGIN\s*(?:RSA|DSA|EC|OPENSSH|PRIVATE)\s*KEY-----)"), "私钥泄露", Severity.CRITICAL),
    (re.compile(r"(?:mongodb|mysql|postgres(?:ql)?|redis|sqlite|sqlserver|oracle)://[^/\s]*:[^/\s]*@"), "数据库连接字符串泄露", Severity.CRITICAL),
    (re.compile(r"(?:eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,})"), "JWT Token 泄露", Severity.HIGH),
    (re.compile(r"AKIA[0-9A-Z]{16}"), "AWS Access Key ID 泄露", Severity.CRITICAL),
    (re.compile(r"(?:sk-[a-zA-Z0-9]{32,})"), "Stripe 密钥泄露", Severity.CRITICAL),
    (re.compile(r"(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{36,}"), "GitHub Token 泄露", Severity.CRITICAL),
    (re.compile(r"AIza[0-9A-Za-z\-_]{35}"), "Google API Key 泄露", Severity.HIGH),
    (re.compile(r"(?:xox[bpras]-[a-zA-Z0-9-]+)"), "Slack Token 泄露", Severity.HIGH),
    (re.compile(r'\.git/'), "Git 仓库引用", Severity.CRITICAL),
    (re.compile(r'\.env["\']'), "环境变量文件引用", Severity.CRITICAL),
    (re.compile(r'\.ht(?:access|passwd)'), "Apache 配置文件引用", Severity.HIGH),
    (re.compile(r'(?:wp-config|settings\.php|database\.yml|database\.yaml)'), "配置文件引用", Severity.HIGH),
    (re.compile(r"phpinfo\(\)"), "PHP phpinfo 函数调用", Severity.CRITICAL),
    (re.compile(r"console\.log\(.*?(?:token|password|secret|key|credential)"), "控制台日志含敏感数据", Severity.HIGH),
    (re.compile(r"DEBUG\s*=\s*True"), "DEBUG 模式开启", Severity.HIGH),
    (re.compile(r"(?:Exception|Error|Traceback|Stack\s*trace):[^\n]{20,}"), "错误堆栈信息泄露", Severity.MEDIUM),
    (re.compile(r'\.(?:git|svn|hg|bzr)/'), "版本控制目录泄露", Severity.CRITICAL),
    (re.compile(r'(?:\.gitignore|\.gitattributes|\.gitmodules)'), "Git 元数据文件", Severity.HIGH),
    (re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"), "邮箱地址暴露", Severity.LOW),
]

XSS_PATTERNS = [
    (re.compile(r'<script>alert\('), "反射型 XSS — alert() 调用"),
    (re.compile(r'<script>\s*document\.cookie'), "XSS — Cookie 窃取代码"),
    (re.compile(r'<img[^>]+onerror\s*=\s*["\']?\s*alert'), "XSS — img onerror 事件"),
    (re.compile(r'<svg[^>]+onload\s*=\s*["\']?\s*alert'), "XSS — SVG onload 事件"),
    (re.compile(r'javascript:\s*alert\('), "XSS — javascript: 伪协议"),
    (re.compile(r'eval\(\s*(?:location|document|window)\s*\.'), "XSS — eval() 动态执行"),
    (re.compile(r'document\.write\(\s*(?:location|document|window)'), "XSS — document.write() 注入"),
    (re.compile(r'<iframe[^>]+srcdoc\s*='), "XSS — iframe srcdoc 注入"),
]

SQLI_PATTERNS = [
    (re.compile(r"SQL\s*syntax.*error"), "SQL 语法错误泄露"),
    (re.compile(r"mysql_fetch_(?:array|row|assoc|object)"), "MySQL 错误泄露"),
    (re.compile(r"pg_query\(\)"), "PostgreSQL 错误泄露"),
    (re.compile(r"Warning:.*mysql_"), "MySQL 警告信息泄露"),
    (re.compile(r"Microsoft OLE DB.*SQL Server"), "SQL Server 错误泄露"),
    (re.compile(r"ODBC Driver.*SQL Server"), "ODBC SQL Server 错误"),
    (re.compile(r"SQLite/JDBCDriver"), "SQLite 错误泄露"),
    (re.compile(r"ORA-\d{5}"), "Oracle 错误代码"),
    (re.compile(r"PLS-\d{5}"), "Oracle PL/SQL 错误"),
    (re.compile(r"PostgreSQL.*ERROR"), "PostgreSQL 错误"),
    (re.compile(r"Warning.*\bpg_\w+\b"), "PostgreSQL 函数警告"),
    (re.compile(r"Unclosed quotation mark"), "SQL 注入 — 未闭合引号"),
    (re.compile(r"You have an error in your SQL syntax"), "SQL 注入 — 语法错误回显"),
]

REDIRECT_PATTERNS = [
    (re.compile(r'redirect(?:\.php|\.aspx|\.jsp)?\?(?:url|to|goto|redirect|next|return)=https?://'), "开放重定向端点"),
    (re.compile(r'(?:url|to|goto|redirect|next|return)=https?://'), "URL 跳转参数"),
    (re.compile(r'window\.location\s*=\s*(?:location|document|window)'), "客户端重定向注入"),
    (re.compile(r'Response\.Redirect\s*\(\s*(?:Request|Server)'), "ASP.NET 服务端重定向"),
]

INFO_LEAK_PATTERNS = [
    (re.compile(r'<!--\s*(?:TODO|FIXME|HACK|XXX|BUG|TEMP|HOTFIX)'), "开发者注释含标记"),
    (re.compile(r'<!--\s*(?:password|secret|key|token|user|admin)'), "HTML 注释含敏感关键词"),
    (re.compile(r'<input[^>]*type=["\']hidden["\'][^>]*>'), "隐藏表单字段"),
    (re.compile(r'<form[^>]*action=["\']([^"\']+)["\']'), "表单提交端点"),
    (re.compile(r'<title>Index of /'), "目录浏览已开启"),
    (re.compile(r'\[DIR\]|To Parent Directory'), "Apache 目录浏览"),
    (re.compile(r'Directory Listing For'), "目录浏览已开启"),
]

COMMENT_PATTERN = re.compile(r'<!--(.*?)-->', re.DOTALL)
HIDDEN_FIELD_PATTERN = re.compile(r'<input[^>]*type=["\']hidden["\'][^>]*>', re.I)
FORM_ACTION_PATTERN = re.compile(r'<form[^>]*action=["\']([^"\']+)["\']', re.I)
DIR_LIST_PATTERN = re.compile(r'\[DIR\]|To Parent Directory')


class ContentAnalyzer:
    """页面内容安全分析器"""

    def __init__(self, engine: HTTPEngine, base_url: str):
        self.engine = engine
        self.base_url = base_url
        self._results: list[AnalysisResult] = []
        self._rate_limited = False

    @property
    def results(self) -> list[AnalysisResult]:
        return self._results

    @property
    def is_rate_limited(self) -> bool:
        return self._rate_limited

    async def analyze_urls(self, urls: list) -> list[AnalysisResult]:
        responses = await self.engine.request_many(urls)
        for resp in responses:
            if resp.status == 200 and resp.body:
                self._results.append(self._analyze_response(resp))
            if resp.status == 429:
                self._rate_limited = True
        return self._results

    async def analyze_response(self, resp: HttpResponse) -> AnalysisResult:
        result = self._analyze_response(resp)
        self._results.append(result)
        return result

    def _analyze_response(self, resp: HttpResponse) -> AnalysisResult:
        findings = []
        if not resp.body:
            return AnalysisResult(url=resp.url)

        # 1. 敏感内容检测
        for pattern, desc, sev in SENSITIVE_REGEX:
            for match in pattern.finditer(resp.body):
                ctx_start = max(0, match.start() - 40)
                ctx_end = min(len(resp.body), match.end() + 40)
                ctx = resp.body[ctx_start:ctx_end].replace("\n", " ").strip()
                findings.append(ContentFinding(
                    finding_type="敏感信息泄露",
                    detail=f"{desc}: {match.group(0)[:150]}",
                    severity=sev,
                    url=resp.url,
                    context=ctx,
                ))

        # 2. XSS 检测
        for pattern, desc in XSS_PATTERNS:
            match = pattern.search(resp.body)
            if match:
                findings.append(ContentFinding(
                    finding_type="XSS 跨站脚本",
                    detail=desc,
                    severity=Severity.HIGH,
                    url=resp.url,
                    context=match.group(0)[:200],
                ))

        # 3. SQL 注入检测
        for pattern, desc in SQLI_PATTERNS:
            match = pattern.search(resp.body)
            if match:
                findings.append(ContentFinding(
                    finding_type="SQL 注入/错误",
                    detail=desc,
                    severity=Severity.HIGH,
                    url=resp.url,
                    context=match.group(0)[:200],
                ))

        # 4. 开放重定向 / SSRF
        for pattern, desc in REDIRECT_PATTERNS:
            match = pattern.search(resp.body)
            if match:
                findings.append(ContentFinding(
                    finding_type="重定向/跳转风险",
                    detail=desc,
                    severity=Severity.MEDIUM,
                    url=resp.url,
                    context=match.group(0)[:200],
                ))

        # 5. 信息泄露
        for pattern, desc in INFO_LEAK_PATTERNS:
            match = pattern.search(resp.body)
            if match:
                findings.append(ContentFinding(
                    finding_type="信息泄露",
                    detail=desc,
                    severity=Severity.LOW,
                    url=resp.url,
                    context=match.group(0)[:200],
                ))

        # 6. HTML 注释分析
        for match in COMMENT_PATTERN.finditer(resp.body):
            comment = match.group(1).strip()
            if len(comment) > 5 and not comment.startswith("["):
                sensitive_kw = ["TODO", "FIXME", "HACK", "password", "secret",
                                "token", "key", "user", "admin", "debug", "test"]
                has_sensitive = any(kw.lower() in comment.lower() for kw in sensitive_kw)
                findings.append(ContentFinding(
                    finding_type="HTML 注释",
                    detail=f"{'敏感 ' if has_sensitive else ''}HTML 注释: {comment[:250]}",
                    severity=Severity.LOW if has_sensitive else Severity.INFO,
                    url=resp.url,
                    context=comment[:200],
                ))

        # 7. 隐藏表单字段
        for match in HIDDEN_FIELD_PATTERN.finditer(resp.body):
            field_html = match.group(0)
            name_match = re.search(r'name=["\']([^"\']+)["\']', field_html)
            field_name = name_match.group(1) if name_match else "unknown"
            findings.append(ContentFinding(
                finding_type="隐藏表单字段",
                detail=f"隐藏输入字段: {field_name}",
                severity=Severity.LOW,
                url=resp.url,
            ))

        # 8. 表单端点
        for match in FORM_ACTION_PATTERN.finditer(resp.body):
            action = match.group(1)
            findings.append(ContentFinding(
                finding_type="表单端点",
                detail=f"表单提交地址: {action}",
                severity=Severity.INFO,
                url=resp.url,
            ))

        # 9. 目录浏览检测
        if (re.search(r'<title>Index of /', resp.body, re.I) or
            re.search(r'<h1>Index of /', resp.body, re.I) or
            DIR_LIST_PATTERN.search(resp.body)):
            findings.append(ContentFinding(
                finding_type="目录浏览",
                detail="目录浏览功能已开启，可遍历服务器文件",
                severity=Severity.HIGH,
                url=resp.url,
            ))

        return AnalysisResult(url=resp.url, findings=findings)

    def all_findings(self) -> list[ContentFinding]:
        all_f = []
        for result in self._results:
            all_f.extend(result.findings)
        return sorted(all_f, key=lambda f: f.severity.score, reverse=True)

    def summary(self) -> dict:
        counts = {}
        for f in self.all_findings():
            counts[f.severity.label] = counts.get(f.severity.label, 0) + 1
        return {
            "urls_analyzed": len(self._results),
            "total_findings": sum(counts.values()),
            "by_severity": counts,
            "rate_limited": self._rate_limited,
        }
