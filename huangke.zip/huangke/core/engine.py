"""Async HTTP engine — 连接池复用 | 指数退避重试 | UA 轮换 | 代理支持"""

import asyncio
import hashlib
import random
import time
from dataclasses import dataclass, field
from typing import Optional, Callable

import aiohttp

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
]

RETRYABLE_STATUSES = {429, 502, 503, 504}


@dataclass
class HttpResponse:
    url: str
    status: int
    headers: dict
    body: str
    content_type: str
    content_length: int
    elapsed: float
    request_id: str = ""
    retries: int = 0


@dataclass
class EngineConfig:
    timeout: int = 10
    max_retries: int = 3
    retry_backoff: float = 1.5
    follow_redirects: bool = True
    max_redirects: int = 5
    verify_ssl: bool = False
    delay: float = 0.0
    proxy: Optional[str] = None
    cookies: dict = field(default_factory=dict)
    extra_headers: dict = field(default_factory=dict)
    user_agent: Optional[str] = None
    max_concurrency: int = 80
    random_delay: bool = False
    delay_range: tuple = (0.0, 0.0)
    max_body_size: int = 51200  # 0 = unlimited, otherwise max bytes to read


class HTTPEngine:
    """Async HTTP client with connection pooling & exponential backoff."""

    def __init__(self, config: EngineConfig):
        self.config = config
        self._semaphore: Optional[asyncio.Semaphore] = None
        self._session: Optional[aiohttp.ClientSession] = None
        self._last_request_time = 0.0
        self._lock = asyncio.Lock()
        self._stats = {"requests": 0, "errors": 0, "retries": 0, "bytes": 0}
        self._progress_cb: Optional[Callable] = None

    @property
    def stats(self) -> dict:
        return dict(self._stats)

    def on_progress(self, cb: Callable):
        self._progress_cb = cb

    async def __aenter__(self):
        connector = aiohttp.TCPConnector(
            ssl=False if not self.config.verify_ssl else None,
            force_close=False,
            limit=self.config.max_concurrency + 10,
            limit_per_host=self.config.max_concurrency,
            ttl_dns_cache=300,
            enable_cleanup_closed=True,
        )
        timeout = aiohttp.ClientTimeout(
            total=self.config.timeout,
            connect=self.config.timeout * 0.6,
            sock_read=self.config.timeout,
        )
        self._session = aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers=self._default_headers(),
            cookies=self.config.cookies or None,
        )
        self._semaphore = asyncio.Semaphore(self.config.max_concurrency)
        return self

    async def __aexit__(self, *args):
        if self._session:
            await self._session.close()

    def _default_headers(self) -> dict:
        return {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Cache-Control": "no-cache",
            **self.config.extra_headers,
        }

    def _random_ua(self) -> str:
        if self.config.user_agent:
            return self.config.user_agent
        return random.choice(USER_AGENTS)

    async def _apply_delay(self):
        delay = self.config.delay
        if self.config.random_delay:
            lo, hi = self.config.delay_range
            if hi > lo:
                delay = random.uniform(lo, hi)
        if delay > 0:
            async with self._lock:
                now = time.monotonic()
                since = now - self._last_request_time
                if since < delay:
                    await asyncio.sleep(delay - since)
                self._last_request_time = time.monotonic()

    async def request(self, url: str, method: str = "GET") -> HttpResponse:
        if not self._session:
            raise RuntimeError("Engine not started — use 'async with HTTPEngine(cfg) as e:'")

        ua = self._random_ua()
        req_id = hashlib.md5(f"{url}{time.monotonic()}".encode()).hexdigest()[:8]

        last_error = None
        for attempt in range(self.config.max_retries + 1):
            async with self._semaphore:
                await self._apply_delay()
                try:
                    start = time.monotonic()
                    async with self._session.request(
                        method, url,
                        headers={"User-Agent": ua},
                        proxy=self.config.proxy,
                        allow_redirects=self.config.follow_redirects,
                        max_redirects=self.config.max_redirects,
                        ssl=False,
                    ) as resp:
                        # 限流读取 body — 只读前 N 字节，避免大响应拖慢速度
                        if self.config.max_body_size > 0:
                            chunk = await resp.content.read(self.config.max_body_size)
                            body = chunk.decode("utf-8", errors="replace")
                        else:
                            body = await resp.text(errors="replace")
                        elapsed = time.monotonic() - start
                        self._stats["requests"] += 1
                        self._stats["bytes"] += len(body)
                        if self._progress_cb:
                            self._progress_cb()
                        # Retry on server errors
                        if resp.status in RETRYABLE_STATUSES and attempt < self.config.max_retries:
                            await asyncio.sleep(self.config.retry_backoff ** attempt)
                            self._stats["retries"] += 1
                            continue
                        return HttpResponse(
                            url=str(resp.url),
                            status=resp.status,
                            headers={k.lower(): v for k, v in resp.headers.items()},
                            body=body,
                            content_type=resp.headers.get("Content-Type", ""),
                            content_length=len(body),
                            elapsed=elapsed,
                            request_id=req_id,
                            retries=attempt,
                        )
                except (aiohttp.ClientError, asyncio.TimeoutError, OSError) as e:
                    last_error = e
                    self._stats["errors"] += 1
                    if attempt < self.config.max_retries:
                        await asyncio.sleep(self.config.retry_backoff ** (attempt + 1))
                        continue

        raise last_error

    async def request_many(self, urls: list, method: str = "GET") -> list[HttpResponse]:
        tasks = [asyncio.ensure_future(self.request(url, method)) for url in urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        responses = []
        for r in results:
            if isinstance(r, HttpResponse):
                responses.append(r)
            elif isinstance(r, Exception):
                responses.append(HttpResponse(
                    url="", status=-1, headers={}, body=str(r),
                    content_type="", content_length=0, elapsed=0,
                ))
        return responses

    async def check_connectivity(self, url: str) -> bool:
        try:
            resp = await self.request(url)
            return resp.status > 0
        except Exception:
            return False
