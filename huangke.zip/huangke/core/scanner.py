"""Directory & endpoint scanner — 状态码过滤 | 智能递归 | 进度回调"""

import asyncio
import fnmatch
import re
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

from rich import print as rprint

from ..core.engine import HTTPEngine, HttpResponse
from ..utils.helpers import extract_paths_from_html, join_url, normalize_url, detect_service
from ..utils.risk import Severity, assess_url_finding


@dataclass
class ScanResult:
    path: str
    url: str
    status: int
    content_type: str
    content_length: int
    elapsed: float
    severity: Severity
    risk_desc: str
    body_preview: str = ""
    discovered_paths: list = field(default_factory=list)
    request_id: str = ""
    service: str = ""  # detected service/framework


@dataclass
class ScanConfig:
    recursive: bool = False
    max_depth: int = 2
    include_status: Optional[list] = None
    exclude_status: Optional[list] = None  # None defaults to [404] at scan time
    min_content_length: int = 0
    max_content_length: int = 0
    match_pattern: Optional[str] = None
    filter_pattern: Optional[str] = None
    extensions: Optional[list] = None  # None = use curated default
    recursion_wordlist_fraction: float = 0.3


# 精简扩展名 — 只留最高频的，减少请求量 10x+
CURATED_EXTENSIONS = [
    ".php", ".asp", ".aspx", ".jsp",      # Web code
    ".json", ".xml", ".env",               # Config/data
    ".bak", ".zip", ".sql", ".txt",        # Backups & text
    ".js", ".html", ".git",                # Source & meta
]

# Paths that are clearly directory names (ending with / in wordlist or start patterns)
DIRECTORY_PATTERNS = [
    "admin", "api", "assets", "backup", "css", "data", "docs",
    "files", "img", "images", "includes", "js", "lib", "media",
    "static", "template", "templates", "tmp", "upload", "uploads",
    "vendor", "wp-admin", "wp-content", "wp-includes",
]


class DirectoryScanner:
    """目录与接口暴力扫描器 — 带实时进度输出"""

    def __init__(self, engine: HTTPEngine, base_url: str, wordlist: list,
                 config: ScanConfig = None,
                 on_progress: Callable = None):
        self.engine = engine
        self.base_url = normalize_url(base_url)
        self.wordlist = [w.strip() for w in wordlist if w.strip() and not w.strip().startswith("#")]
        self.config = config or ScanConfig()
        self._on_progress = on_progress
        self._seen_urls: set = set()
        self._results: list[ScanResult] = []
        self._total_requests = 0
        self._completed_requests = 0
        self._start_time = 0

    @property
    def results(self) -> list[ScanResult]:
        return sorted(self._results, key=lambda r: r.severity.score, reverse=True)

    @property
    def progress(self) -> tuple:
        return self._completed_requests, self._total_requests

    async def scan(self) -> list[ScanResult]:
        self._seen_urls = set()
        self._results = []
        self._completed_requests = 0
        self._start_time = time.time()

        # Quick reachability test (first request, no retries)
        try:
            resp = await self.engine.request(self.base_url)
            if resp.status <= 0:
                rprint(f"  [red]目标不可达: {self.base_url}[/red]")
                return self._results
            base_status = resp.status
        except Exception:
            rprint(f"  [red]目标连接失败: {self.base_url}[/red]")
            return self._results

        if self.config.extensions is None:
            self.config.extensions = CURATED_EXTENSIONS

        # ── Pass 1: 扫基础路径 (不带扩展名) ──
        base_paths = [w.strip() for w in self.wordlist if w.strip() and not w.strip().startswith("#")]
        self._total_requests = len(base_paths)
        rprint(f"\n  [cyan]→ Pass 1: 扫描 {len(base_paths)} 个基础路径...[/cyan]")
        rprint(f"  [dim]   基准状态: {base_status}[/dim]")

        await self._scan_paths(base_paths, depth=0)
        rprint(f"  [green]✓ Pass 1 完成: {len(self._results)} 个发现[/green]")

        # ── Pass 2: 只对有效路径加扩展名扫 ──
        if self.config.extensions and self._results:
            # 收集返回了有意义状态码的路径 (非 404 过滤掉的)
            interesting = set()
            for r in self._results:
                if not r.path.endswith("/"):
                    base = r.path.split(".")[0] if "." in r.path.split("/")[-1] else r.path
                    if base not in interesting:
                        interesting.add(base)

            ext_paths = []
            for base in interesting:
                for ext in self.config.extensions:
                    ext_path = f"{base}{ext}"
                    if ext_path not in interesting:
                        ext_paths.append(ext_path)

            if ext_paths:
                self._total_requests += len(ext_paths)
                rprint(f"  [cyan]→ Pass 2: 扩展 {len(ext_paths)} 个路径 (从 {len(interesting)} 个发现)...[/cyan]")
                await self._scan_paths(ext_paths, depth=0)
                rprint(f"  [green]✓ Pass 2 完成: 新增 {len(self._results) - len(interesting)} 个发现[/green]")

        elapsed = time.time() - self._start_time
        found = len(self._results)
        rprint(f"  [green]✓ 扫描完成: {found} 个发现 | {elapsed:.1f}s | {self._completed_requests} 请求[/green]")
        return self.results

    def _expand_wordlist_smart(self, paths: list) -> list:
        """Smarter wordlist expansion: only add extensions to likely file paths."""
        expanded = []
        dir_lower = set(p.lower().strip("/") for p in DIRECTORY_PATTERNS)

        for path in paths:
            path = path.strip()
            if not path:
                continue
            expanded.append(path)

            # Only add extensions for entries that look like files (not dirs)
            base = path.rstrip("/")
            last_part = base.split("/")[-1] if "/" in base else base

            # Skip dir-like names
            is_dir = (
                path.endswith("/") or
                last_part.lower() in dir_lower or
                last_part in ("",) or
                not last_part  # empty
            )

            if not is_dir and "." not in last_part:
                # Add the most common extensions for this path
                for ext in self.config.extensions:
                    ext_clean = ext.lstrip(".")
                    expanded.append(f"{base}.{ext_clean}")

        # Remove duplicates preserving order
        seen = set()
        result = []
        for item in expanded:
            if item not in seen:
                seen.add(item)
                result.append(item)
        return result

    def _expand_wordlist(self, paths: list) -> list:
        """Legacy expansion — used as fallback."""
        return self._expand_wordlist_smart(paths)

    async def _scan_paths(self, paths: list, depth: int):
        urls, path_map = [], {}
        for p in paths:
            if not p:
                continue
            url = join_url(self.base_url, p.lstrip("/"))
            if url in self._seen_urls:
                continue
            self._seen_urls.add(url)
            urls.append(url)
            path_map[url] = p

        if not urls:
            return

        responses = await self.engine.request_many(urls)
        self._completed_requests += len(urls)

        # Real-time progress
        if self._on_progress:
            self._on_progress(self._completed_requests, self._total_requests)
        elif self._completed_requests % 50 == 0 or self._completed_requests == self._total_requests:
            pct = min(100, int(self._completed_requests / max(1, self._total_requests) * 100))
            found = len(self._results)
            rprint(f"  [dim]  进度: {self._completed_requests}/{self._total_requests} ({pct}%) | 已发现: {found}[/dim]")

        found_dirs: list = []
        for req_url, resp in zip(urls, responses):
            if resp.status == -1:
                continue

            # Apply filters
            if not self._accept_response(resp):
                continue

            path = path_map.get(req_url, resp.url)
            content_type = resp.content_type.split(";")[0].strip() if resp.content_type else ""
            sev, desc = assess_url_finding(path, resp.status, content_type)
            body_preview = resp.body[:500] if resp.status == 200 and resp.body else ""

            # Extract discovered paths from HTML
            discovered = []
            is_html = "html" in content_type or (resp.body and "<html" in resp.body[:200].lower())
            if is_html and resp.status == 200:
                discovered = extract_paths_from_html(resp.body, resp.url)

            self._results.append(ScanResult(
                path=path, url=resp.url, status=resp.status,
                content_type=content_type, content_length=resp.content_length,
                elapsed=resp.elapsed, severity=sev, risk_desc=desc,
                body_preview=body_preview, discovered_paths=discovered,
                request_id=resp.request_id, service=detect_service(path),
            ))

            # Show found items immediately with risk & service info
            svc = detect_service(path)
            sev_color = sev.color
            risk_tag = f"  [{sev_color}]{desc[:30]}[/]" if desc else ""
            svc_tag = f"  [dim]{svc}[/]" if svc else ""
            color = "green" if resp.status == 200 else ("yellow" if resp.status < 400 else "red")
            rprint(f"  [{color}]  {resp.status} {path}{risk_tag}{svc_tag}[/]")

            # Collect for recursion
            if self.config.recursive and depth < self.config.max_depth:
                if resp.status in (200, 301, 302, 403) and \
                   resp.url.rstrip("/") != self.base_url.rstrip("/"):
                    found_dirs.append(resp.url)
                for dp in discovered:
                    du = join_url(self.base_url, dp.strip("/"))
                    if du not in self._seen_urls:
                        found_dirs.append(du)

        # Recursive scan
        if self.config.recursive and depth < self.config.max_depth and found_dirs:
            base_parsed = self.base_url.rstrip("/")
            new_paths = []
            limit = max(10, int(len(self.wordlist) * self.config.recursion_wordlist_fraction))
            for dir_url in found_dirs[:30]:
                if dir_url.startswith(base_parsed):
                    relative = dir_url[len(base_parsed):].strip("/")
                    if relative:
                        for w in self.wordlist[:limit]:
                            sub = f"{relative}/{w.strip()}"
                            if join_url(self.base_url, sub) not in self._seen_urls:
                                new_paths.append(sub)
            if new_paths:
                self._total_requests += len(new_paths)
                await self._scan_paths(new_paths, depth + 1)

    def _accept_response(self, resp: HttpResponse) -> bool:
        exclude = self.config.exclude_status if self.config.exclude_status is not None else [404]
        include = self.config.include_status
        if include and resp.status not in include:
            return False
        if resp.status in exclude:
            return False
        if self.config.min_content_length > 0 and resp.content_length < self.config.min_content_length:
            return False
        if self.config.max_content_length > 0 and resp.content_length > self.config.max_content_length:
            return False
        if self.config.match_pattern and not re.search(self.config.match_pattern, resp.body, re.I):
            return False
        if self.config.filter_pattern and re.search(self.config.filter_pattern, resp.body, re.I):
            return False
        return True

    def summary(self) -> dict:
        counts = {}
        for r in self._results:
            counts[r.severity.label] = counts.get(r.severity.label, 0) + 1
        return {
            "total_scanned": len(self._results),
            "total_requests": self._total_requests,
            "by_severity": counts,
        }
