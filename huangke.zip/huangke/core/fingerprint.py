"""Web technology fingerprinting — 技术栈 | CMS | WAF | CDN | 安全头"""

import asyncio
import functools
import hashlib
import re
from dataclasses import dataclass, field
from urllib.parse import urljoin

from ..core.engine import HTTPEngine, HttpResponse
from ..data.signatures import (
    SERVER_SIGNATURES, COOKIE_SIGNATURES, JS_SIGNATURES,
    CMS_SIGNATURES, HEADER_SIGNATURES, WAF_SIGNATURES,
)

# CDN detection via headers and CNAME
CDN_PROVIDERS = {
    "Cloudflare": [r"cloudflare", r"cf-ray", r"__cfduid", r"__cf_bm", r"cf_clearance"],
    "Akamai": [r"akamai", r"akamaighost", r"edgesuite", r"edgekey"],
    "Fastly": [r"fastly", r"fastly\.net", r"x-served-by"],
    "Amazon CloudFront": [r"cloudfront", r"x-amz-cf-", r"d\.cloudfront\.net"],
    "Google Cloud CDN": [r"googlesyndication", r"gstatic\.com"],
    "Azure CDN": [r"azureedge", r"vo\.msecnd\.net", r"azurefd\.net"],
    "StackPath": [r"stackpath", r"stackpathdns"],
    "KeyCDN": [r"keycdn", r"kxcdn\.com"],
    "CDN77": [r"cdn77", r"cdn77\.org"],
    "BunnyCDN": [r"bunnycdn", r"b-cdn\.net"],
    "CacheFly": [r"cachefly"],
    "Edgecast": [r"edgecast", r"ecdns\.net", r"verizondigitalmedia"],
    "Limelight": [r"limelight", r"llnwd\.net"],
    "MaxCDN/StackPath": [r"maxcdn", r"netdna"],
    "ChinaCache": [r"chinacache", r"ccgslb\.com\.cn"],
    "Alibaba Cloud CDN": [r"alicdn\.com", r"kunlun"],
    "Tencent Cloud CDN": [r"qcloud\.com", r"cdn\.myqcloud"],
    "Sucuri": [r"sucuri"],
    "Imperva": [r"imperva", r"incapsula"],
    "Reblaze": [r"reblaze"],
}


@dataclass
class FingerprintResult:
    category: str
    name: str
    evidence: str
    confidence: str


@dataclass
class ServerInfo:
    ip: str = ""
    server: str = ""
    powered_by: str = ""
    generator: str = ""
    page_title: str = ""
    status_line: str = ""
    technologies: list = field(default_factory=list)
    waf: list = field(default_factory=list)
    cdn: list = field(default_factory=list)
    headers: dict = field(default_factory=dict)
    cookies: dict = field(default_factory=dict)
    security_headers: dict = field(default_factory=dict)


class WebFingerprinter:
    """识别 Web 服务器技术栈 — 每个检测器独立容错"""

    _re_cache = functools.lru_cache(maxsize=512)(re.compile)

    SECURITY_HEADERS = {
        "content-security-policy", "x-frame-options", "x-content-type-options",
        "strict-transport-security", "referrer-policy", "permissions-policy",
        "x-xss-protection", "x-permitted-cross-domain-policies",
        "cross-origin-resource-policy", "cross-origin-opener-policy",
        "cross-origin-embedder-policy", "x-download-options",
        "x-dns-prefetch-control",
    }

    def __init__(self, engine: HTTPEngine, base_url: str):
        self.engine = engine
        self.base_url = base_url

    async def fingerprint(self) -> ServerInfo:
        info = ServerInfo()

        # Step 1: Fetch main page — any failure returns empty info
        try:
            resp = await self.engine.request(self.base_url)
        except (asyncio.TimeoutError, ConnectionError, OSError, Exception):
            return info

        if not resp or resp.status == -1:
            return info

        try:
            info.headers = dict(resp.headers)
            info.status_line = f"HTTP/{resp.status}"

            # Page title
            title_match = re.search(r'<title[^>]*>([^<]+)</title>', resp.body or "", re.I)
            if title_match:
                info.page_title = title_match.group(1).strip()

            # Run each detector in isolation — one failure won't break others
            for detector in [
                self._extract_ip, self._extract_server_info,
                self._detect_cookies, self._detect_from_headers,
                self._detect_security_headers, self._detect_js_libraries,
                self._detect_cms, self._detect_waf, self._detect_cdn,
            ]:
                try:
                    detector(resp, info)
                except Exception:
                    continue

            # Probe robots.txt & favicon.ico concurrently with timeout
            async def _probe_robots():
                try:
                    r = await asyncio.wait_for(self.engine.request(urljoin(self.base_url, "/robots.txt")), timeout=5)
                    if r.status == 200:
                        self._analyze_robots(r, info)
                except Exception:
                    pass

            async def _probe_favicon():
                try:
                    r = await asyncio.wait_for(self.engine.request(urljoin(self.base_url, "/favicon.ico")), timeout=5)
                    if r.status == 200 and r.body:
                        self._analyze_favicon(r, info)
                except Exception:
                    pass

            try:
                await asyncio.gather(_probe_robots(), _probe_favicon())
            except Exception:
                pass
        except Exception:
            pass

        return info

    def _extract_ip(self, resp: HttpResponse, info: ServerInfo):
        for hdr in ("x-forwarded-for", "x-real-ip", "x-client-ip", "cf-connecting-ip"):
            val = resp.headers.get(hdr, "")
            if val:
                info.ip = val.split(",")[0].strip()
                return
        try:
            import socket
            from urllib.parse import urlparse
            host = urlparse(resp.url).hostname
            if host:
                info.ip = socket.gethostbyname(host)
        except Exception:
            pass

    def _extract_server_info(self, resp: HttpResponse, info: ServerInfo):
        try:
            server = resp.headers.get("server", "") or ""
            info.server = server
            if server:
                for name, patterns in SERVER_SIGNATURES.items():
                    for p in patterns:
                        if p.lower() in server.lower():
                            info.technologies.append(FingerprintResult(
                                category="Web Server", name=name,
                                evidence=f"Server: {server}", confidence="high",
                            ))
                            break

            powered = resp.headers.get("x-powered-by", "") or ""
            info.powered_by = powered
            if powered:
                info.technologies.append(FingerprintResult(
                    category="Framework", name=powered,
                    evidence=f"X-Powered-By: {powered}", confidence="high",
                ))

            gen_match = re.search(r'<meta[^>]*name="generator"[^>]*content="([^"]+)"', resp.body or "", re.I)
            if gen_match:
                info.generator = gen_match.group(1)
                info.technologies.append(FingerprintResult(
                    category="CMS/Generator", name=info.generator,
                    evidence=f'Meta generator: {info.generator}', confidence="high",
                ))
        except Exception:
            pass

    def _detect_cookies(self, resp: HttpResponse, info: ServerInfo):
        try:
            set_cookie = resp.headers.get("set-cookie", "") or ""
            cookies_found = {}
            for cookie_line in set_cookie.split(","):
                cookie_line = cookie_line.strip()
                if "=" in cookie_line:
                    name = cookie_line.split("=")[0].strip()
                    cookies_found[name] = cookie_line
            info.cookies = cookies_found

            for cookie_name in cookies_found:
                for tech_name, cookie_patterns in COOKIE_SIGNATURES.items():
                    if cookie_name in cookie_patterns:
                        already = any(
                            t.name == tech_name and t.category == "Technology"
                            for t in info.technologies
                        )
                        if not already:
                            info.technologies.append(FingerprintResult(
                                category="Technology", name=tech_name,
                                evidence=f"Cookie: {cookie_name}", confidence="medium",
                            ))
        except Exception:
            pass

    def _detect_from_headers(self, resp: HttpResponse, info: ServerInfo):
        try:
            for header_name, tech_hint in HEADER_SIGNATURES.items():
                value = resp.headers.get(header_name.lower(), "") or ""
                if value:
                    if tech_hint:
                        info.technologies.append(FingerprintResult(
                            category="Technology", name=tech_hint,
                            evidence=f"{header_name}: {value}", confidence="medium",
                        ))
                    else:
                        info.technologies.append(FingerprintResult(
                            category="Header", name=header_name,
                            evidence=f"{header_name}: {value}", confidence="low",
                        ))
        except Exception:
            pass

    def _detect_security_headers(self, resp: HttpResponse, info: ServerInfo):
        try:
            for sh in self.SECURITY_HEADERS:
                value = resp.headers.get(sh, "") or ""
                info.security_headers[sh] = value if value else "MISSING"
        except Exception:
            pass

    def _detect_js_libraries(self, resp: HttpResponse, info: ServerInfo):
        try:
            body = resp.body or ""
            for lib, patterns in JS_SIGNATURES.items():
                for pattern in patterns:
                    if re.search(pattern, body, re.I):
                        confidence = "medium"
                        if "min" in pattern or "/dist/" in pattern:
                            confidence = "high"
                        elif "??" in pattern:
                            confidence = "low"
                        info.technologies.append(FingerprintResult(
                            category="JavaScript", name=lib,
                            evidence=f"Match: {pattern}", confidence=confidence,
                        ))
                        break
        except Exception:
            pass

    def _detect_cms(self, resp: HttpResponse, info: ServerInfo):
        try:
            body = resp.body or ""
            for cms, signatures in CMS_SIGNATURES.items():
                for pattern, evidence_type in signatures:
                    try:
                        if re.search(pattern, body, re.I):
                            confidence = "high" if evidence_type in ("Meta", "Path") else "medium"
                            info.technologies.append(FingerprintResult(
                                category="CMS/Platform", name=cms,
                                evidence=f"{evidence_type}: {pattern}", confidence=confidence,
                            ))
                            break
                    except re.error:
                        continue
        except Exception:
            pass

    def _detect_waf(self, resp: HttpResponse, info: ServerInfo):
        try:
            body = (resp.body or "")[:15000] if resp.body else ""
            all_headers = " ".join(f"{k}: {v}" for k, v in resp.headers.items())
            for waf_name, signatures in WAF_SIGNATURES.items():
                for pattern_str, ev_type in signatures:
                    try:
                        if ev_type == "Server":
                            search_text = resp.headers.get("server", "") or ""
                        elif ev_type == "Cookie":
                            search_text = resp.headers.get("set-cookie", "") or ""
                        elif ev_type == "Header":
                            search_text = all_headers
                        else:
                            search_text = body

                        if self._re_cache(pattern_str, re.I).search(search_text):
                            info.waf.append(FingerprintResult(
                                category="WAF", name=waf_name,
                                evidence=f"{ev_type}: {pattern_str}", confidence="medium",
                            ))
                            break
                    except re.error:
                        continue
        except Exception:
            pass

    def _detect_cdn(self, resp: HttpResponse, info: ServerInfo):
        try:
            all_text = " ".join([
                resp.headers.get("server", "") or "",
                resp.headers.get("set-cookie", "") or "",
                " ".join(f"{k}: {v}" for k, v in resp.headers.items()),
                (resp.body or "")[:5000],
            ])

            for cdn_name, patterns in CDN_PROVIDERS.items():
                for pattern_str in patterns:
                    if self._re_cache(pattern_str, re.I).search(all_text):
                        info.cdn.append(FingerprintResult(
                            category="CDN", name=cdn_name,
                            evidence=f"Match: {pattern_str}",
                            confidence="high" if cdn_name in ("Cloudflare", "Akamai", "Fastly") else "medium",
                        ))
                        break
        except Exception:
            pass

    def _analyze_robots(self, resp: HttpResponse, info: ServerInfo):
        try:
            disallowed = re.findall(r'Disallow:\s*(.+)', resp.body or "", re.I)
            if disallowed:
                info.technologies.append(FingerprintResult(
                    category="robots.txt", name="Disallowed paths",
                    evidence=f"Found {len(disallowed)} disallowed paths", confidence="low",
                ))
        except Exception:
            pass

    def _analyze_favicon(self, resp: HttpResponse, info: ServerInfo):
        try:
            body_bytes = resp.body
            if not body_bytes:
                return
            if isinstance(body_bytes, str):
                body_bytes = body_bytes.encode("utf-8", errors="replace")
            h = hashlib.md5(body_bytes).hexdigest()
            FAVICON_HASHES = {
                "e5a2d1e7c1bb9b3c5a5a3c4b1d0a1f2a": "WordPress",
                "f1a6e5e5c5a5b9a9b1b2a3b4c5d6e7f8": "Drupal",
                "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6": "Joomla",
                "c5d6e7f8a1b2c3d4e5f6a7b8c9d0e1f2": "Magento",
                "b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6": "Shopify",
                "d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9": "ClickFunnels",
                "f0e1d2c3b4a59687": "Jenkins",
                "e3b0c44298fc1c149afbf4c8996fb924": "cPanel",
            }
            for fav_hash, cms in FAVICON_HASHES.items():
                if h == fav_hash:
                    info.technologies.append(FingerprintResult(
                        category="Favicon", name=f"Favicon matches {cms}",
                        evidence=f"MD5: {h}", confidence="high",
                    ))
                    break
        except Exception:
            pass

    def summary(self, info: ServerInfo) -> dict:
        return {
            "server": info.server or "Unknown",
            "page_title": info.page_title or "",
            "technologies": [t.name for t in info.technologies],
            "tech_count": len(info.technologies),
            "waf_detected": [w.name for w in info.waf],
            "cdn_detected": [c.name for c in info.cdn],
            "generator": info.generator or "",
            "missing_security_headers": [
                k for k, v in info.security_headers.items() if v == "MISSING"
            ],
            "security_header_score": sum(
                1 for v in info.security_headers.values() if v != "MISSING"
            ),
        }
