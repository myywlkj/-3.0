"""异步端口扫描引擎"""

import asyncio
import socket
from dataclasses import dataclass, field

from ..utils.risk import Severity, assess_port_finding

# 高危端口 — 默认被恶意利用
DANGEROUS_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    110: "POP3", 135: "RPC", 139: "NetBIOS", 143: "IMAP",
    445: "SMB", 514: "rsh", 873: "rsync", 993: "IMAPS", 995: "POP3S",
    1080: "SOCKS", 1433: "MSSQL", 1521: "Oracle", 1723: "PPTP",
    2049: "NFS", 2082: "cPanel", 2083: "cPanel SSL", 2222: "SSH-alt",
    2375: "Docker", 2376: "Docker TLS", 3306: "MySQL", 3389: "RDP",
    5000: "Docker Registry", 5432: "PostgreSQL", 5601: "Kibana",
    5672: "RabbitMQ", 5900: "VNC", 5984: "CouchDB", 6379: "Redis",
    6443: "K8s API", 7001: "WebLogic", 7002: "WebLogic SSL", 7474: "Neo4j",
    8000: "HTTP-alt", 8009: "AJP", 8080: "HTTP-proxy", 8089: "Splunk",
    8443: "HTTPS-alt", 8888: "HTTP-alt", 9000: "PHP-FPM", 9090: "Cockpit",
    9200: "Elasticsearch", 9300: "Elasticsearch", 10000: "Webmin",
    11211: "Memcached", 15672: "RabbitMQ Mgmt", 27017: "MongoDB",
    27018: "MongoDB", 28017: "MongoDB Web", 50070: "Hadoop",
}

WEB_PORTS = {80, 81, 443, 3000, 4443, 5000, 5222, 8000, 8080, 8081, 8083, 8088, 8443, 8888, 9000, 9090, 9443, 10443}
DATABASE_PORTS = {1433, 1521, 3306, 5432, 6379, 8529, 9200, 9300, 11211, 27017}
REMOTE_PORTS = {22, 23, 135, 445, 3389, 5632, 5900, 5901, 5985, 5986}
MAIL_PORTS = {25, 110, 143, 465, 587, 993, 995, 2525}

_EXTRA_PORTS = [
    7, 13, 19, 37, 49, 67, 68, 69, 70, 79, 88, 102, 111, 113, 119, 123, 137, 138, 161, 162, 177, 179, 194,
    201, 264, 318, 381, 383, 389, 411, 412, 427, 443, 464, 465, 497, 500, 512, 513, 515, 520, 540, 543, 544,
    546, 547, 548, 554, 587, 591, 593, 623, 631, 636, 639, 646, 691, 860, 902, 989, 990, 992, 1025, 1026,
    1080, 1099, 1175, 1194, 1200, 1214, 1220, 1234, 1241, 1311, 1337, 1344, 1352, 1433, 1434, 1443, 1471,
    1494, 1500, 1503, 1521, 1524, 1533, 1556, 1583, 1594, 1627, 1701, 1717, 1720, 1723, 1755, 1761, 1812,
    1813, 1863, 1900, 1935, 1985, 2000, 2002, 2030, 2049, 2082, 2083, 2086, 2087, 2095, 2096, 2100, 2105,
    2121, 2152, 2161, 2181, 2196, 2222, 2251, 2260, 2288, 2301, 2323, 2366, 2381, 2382, 2393, 2399, 2401,
    2443, 2460, 2480, 2500, 2522, 2525, 2601, 2604, 2612, 2638, 2710, 2717, 2800, 2809, 2944, 2945, 2947,
    2948, 2949, 2967, 3001, 3005, 3006, 3031, 3050, 3071, 3128, 3225, 3260, 3283, 3300, 3333, 3343, 3389,
    3396, 3443, 3493, 3516, 3527, 3546, 3551, 3580, 3632, 3659, 3689, 3690, 3702, 3749, 3780, 3800, 3801,
    3827, 3869, 3871, 3878, 3880, 3900, 3912, 3920, 3940, 3995, 4000, 4040, 4111, 4190, 4224, 4242, 4321,
    4343, 4440, 4443, 4500, 4567, 4662, 4664, 4672, 4848, 4889, 4899, 4949, 4998, 5000, 5003, 5050, 5051,
    5060, 5093, 5150, 5190, 5222, 5269, 5280, 5353, 5357, 5405, 5432, 5433, 5498, 5500, 5550, 5555, 5560,
    5601, 5631, 5632, 5666, 5672, 5720, 5800, 5900, 5938, 5984, 5985, 5986, 6000, 6082, 6100, 6112, 6129,
    6267, 6346, 6379, 6443, 6502, 6522, 6543, 6566, 6567, 6600, 6666, 6669, 6699, 6789, 6839, 6868, 6881,
    6891, 6901, 6969, 7000, 7001, 7002, 7004, 7070, 7100, 7200, 7402, 7435, 7443, 7474, 7496, 7512, 7547,
    7625, 7657, 7676, 7777, 7787, 7800, 7911, 8000, 8009, 8010, 8042, 8069, 8070, 8080, 8081, 8083, 8086,
    8087, 8088, 8089, 8090, 8123, 8161, 8181, 8200, 8222, 8243, 8280, 8291, 8333, 8383, 8400, 8443, 8484,
    8500, 8530, 8531, 8580, 8600, 8612, 8649, 8800, 8834, 8840, 8880, 8888, 8899, 8983, 9000, 9001, 9002,
    9060, 9090, 9091, 9100, 9160, 9191, 9200, 9300, 9333, 9443, 9495, 9535, 9595, 9600, 9675, 9696, 9800,
    9876, 9898, 9899, 9900, 9988, 9999, 10000, 10001, 10010, 10050, 10051, 10134, 10215, 10443, 10514,
    11000, 11111, 11112, 11211, 11371, 12000, 12345, 12975, 13580, 13782, 14000, 15000, 15556, 16010, 16030,
    17027, 18000, 18181, 18264, 19150, 20000, 20547, 21025, 22222, 23023, 23456, 24000, 24800, 25734, 26000,
    27000, 27017, 27374, 28017, 28784, 30000, 30718, 31337, 32768, 33333, 33389, 33434, 34443, 37777, 38080,
    38292, 40000, 40193, 41523, 42000, 44818, 45000, 45555, 47001, 47808, 49152, 49153, 50000, 50030, 50070,
    54321, 55555, 60000, 61000, 62078, 63389, 64623, 65000,
]

TOP_PORTS = sorted(DANGEROUS_PORTS.keys()) + sorted(p for p in _EXTRA_PORTS if p not in DANGEROUS_PORTS)


@dataclass
class PortResult:
    port: int
    service: str
    state: str  # "open", "filtered", "closed"
    banner: str = ""
    severity: Severity = Severity.INFO
    risk_desc: str = ""


class PortScanner:
    """异步 TCP 端口扫描器"""

    def __init__(self, host: str, ports: list[int] = None,
                 timeout: float = 2.0, concurrency: int = 500):
        self.host = host
        self.ports = ports or TOP_PORTS
        self.timeout = timeout
        self.concurrency = concurrency
        self._results: list[PortResult] = []

    @property
    def results(self) -> list[PortResult]:
        return sorted(self._results, key=lambda r: r.severity.score, reverse=True)

    async def scan(self) -> list[PortResult]:
        sem = asyncio.Semaphore(self.concurrency)
        tasks = [self._check_port(p, sem) for p in self.ports]
        await asyncio.gather(*tasks)
        return self.results

    async def _check_port(self, port: int, sem: asyncio.Semaphore):
        async with sem:
            try:
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(self.host, port),
                    timeout=self.timeout,
                )
                banner = ""
                try:
                    writer.write(b"\r\n")
                    await writer.drain()
                    banner = (await asyncio.wait_for(reader.read(256), timeout=1.0)).decode("latin-1", errors="replace").strip()
                except Exception:
                    pass
                writer.close()
                await writer.wait_closed()

                service = DANGEROUS_PORTS.get(port, self._guess_service(port, banner))
                sev, desc = assess_port_finding(port, banner)
                self._results.append(PortResult(
                    port=port, service=service, state="开放",
                    banner=banner[:120], severity=sev, risk_desc=desc,
                ))
            except (asyncio.TimeoutError, ConnectionRefusedError, OSError):
                pass  # 端口关闭或过滤

    def _guess_service(self, port: int, banner: str) -> str:
        if port in WEB_PORTS:
            return "HTTP/HTTPS"
        if port in DATABASE_PORTS:
            return "数据库"
        if port in REMOTE_PORTS:
            return "远程管理"
        if port in MAIL_PORTS:
            return "邮件服务"
        bl = banner.lower()
        if "ssh" in bl:
            return "SSH"
        if "ftp" in bl:
            return "FTP"
        if "smtp" in bl:
            return "SMTP"
        if "http" in bl:
            return "HTTP"
        if "mysql" in bl:
            return "MySQL"
        if "postgresql" in bl:
            return "PostgreSQL"
        if "redis" in bl:
            return "Redis"
        if "mongodb" in bl:
            return "MongoDB"
        if "telnet" in bl:
            return "Telnet"
        if "vnc" in bl:
            return "VNC"
        return "未知"

    def summary(self) -> dict:
        counts = {s.label: 0 for s in Severity}
        for r in self._results:
            counts[r.severity.label] += 1
        return {
            "total_scanned": len(self.ports),
            "open_ports": len(self._results),
            "by_severity": counts,
        }
