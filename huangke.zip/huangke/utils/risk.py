"""风险评分引擎 — 五级严重度 | 模式匹配 | 端口评估"""

import re as _re
from enum import Enum


class Severity(Enum):
    CRITICAL = ("严重", "red", 5)
    HIGH = ("高危", "dark_orange", 4)
    MEDIUM = ("中危", "yellow", 3)
    LOW = ("低危", "blue", 2)
    INFO = ("信息", "dim", 1)

    @property
    def label(self) -> str:
        return self.value[0]

    @property
    def color(self) -> str:
        return self.value[1]

    @property
    def score(self) -> int:
        return self.value[2]


# ── Pre-compiled risk patterns ──

def _cp(pattern: str) -> _re.Pattern:
    return _re.compile(pattern, _re.I)

CRITICAL_PATTERNS = [
    (_cp(r'\.git/HEAD'), "Git 仓库泄露"),
    (_cp(r'\.svn/entries'), "SVN 仓库泄露"),
    (_cp(r'\.hg/store'), "Mercurial 仓库泄露"),
    (_cp(r'\.bzr/'), "Bazaar 仓库泄露"),
    (_cp(r'phpinfo\.php'), "PHP 信息页面泄露"),
    (_cp(r'phpinfo\(\)'), "PHP phpinfo 函数泄露"),
    (_cp(r"mysql_connect\s*\("), "数据库凭据泄露"),
    (_cp(r'password\s*=\s*[\'"][^\'"]+[\'"]'), "硬编码密码泄露"),
    (_cp(r'api[_-]?key\s*=\s*[\'"][^\'"]{10,}[\'"]'), "API 密钥泄露"),
    (_cp(r'BEGIN (RSA|DSA|EC|OPENSSH) PRIVATE KEY'), "私钥文件泄露"),
    (_cp(r'(?:mongodb|mysql|postgres(?:ql)?|redis|sqlite|sqlserver)://[^/\s]+:[^/\s]+@'), "数据库连接串泄露"),
    (_cp(r'\.env(\.[a-z]+)?$'), "环境变量文件泄露"),
    (_cp(r'\.htpasswd'), "密码文件泄露"),
    (_cp(r'wp-config\.php'), "WordPress 配置泄露"),
    (_cp(r'wp-config\.bak'), "WordPress 配置备份泄露"),
    (_cp(r'server-status'), "Apache 服务器状态泄露"),
    (_cp(r'/\.DS_Store'), "macOS DS_Store 文件泄露"),
    (_cp(r'(?:id_rsa|id_dsa|id_ecdsa|id_ed25519)'), "SSH 私钥泄露"),
    (_cp(r'\.pem$'), "PEM 证书/密钥泄露"),
    (_cp(r'\.p12$|\.pfx$'), "PKCS12 密钥库泄露"),
    (_cp(r'\.jks$|\.keystore$'), "Java 密钥库泄露"),
    (_cp(r'web\.config$'), "ASP.NET web.config 泄露"),
    (_cp(r'appsettings\.json$'), "ASP.NET Core 配置泄露"),
    (_cp(r'/\.aws/credentials'), "AWS 凭据文件泄露"),
    (_cp(r'/\.dockercfg$|/\.docker/config\.json$'), "Docker 凭据泄露"),
    (_cp(r'/\.npmrc$'), "NPM 配置泄露"),
    (_cp(r'kubeconfig$|\.kube/config$'), "Kubernetes 配置泄露"),
    (_cp(r'terraform\.tfstate'), "Terraform 状态文件泄露"),
    (_cp(r'\.tfvars$'), "Terraform 变量泄露"),
]

HIGH_PATTERNS = [
    (_cp(r'\.bak$|\.backup$|\.old$|\.swp$|~$|\.orig$|\.save$'), "备份文件泄露"),
    (_cp(r'(?:admin|administrator|login|wp-admin|wp-login)\.(?:php|html|aspx|jsp)'), "后台管理页面暴露"),
    (_cp(r'Directory Listing'), "目录浏览已开启"),
    (_cp(r'Index of /'), "目录浏览已开启"),
    (_cp(r'web\.config'), "web.config 配置文件暴露"),
    (_cp(r'\.htaccess'), "Apache .htaccess 暴露"),
    (_cp(r'config\.(?:yml|yaml|json|xml|ini|cfg|conf|toml)'), "配置文件暴露"),
    (_cp(r'upload[s]?/'), "上传目录发现"),
    (_cp(r'backup[s]?/'), "备份目录发现"),
    (_cp(r'dump\.sql|database\.sql|export\.sql|backup\.sql\.gz'), "SQL 数据库导出泄露"),
    (_cp(r'composer\.json'), "Composer 配置暴露"),
    (_cp(r'package\.json'), "NPM 配置暴露"),
    (_cp(r'package-lock\.json'), "NPM 锁文件暴露"),
    (_cp(r'yarn\.lock'), "Yarn 锁文件暴露"),
    (_cp(r'Gemfile$'), "Ruby Gemfile 暴露"),
    (_cp(r'Pipfile$|pipfile\.lock$'), "Python Pipfile 暴露"),
    (_cp(r'docker-compose\.(?:yml|yaml)'), "Docker Compose 文件暴露"),
    (_cp(r'Dockerfile$'), "Dockerfile 暴露"),
    (_cp(r'\.dockerignore$'), "Docker 忽略文件暴露"),
    (_cp(r'nginx\.conf$|nginx/.*\.conf$'), "Nginx 配置暴露"),
    (_cp(r'sites-enabled/'), "Nginx 站点配置暴露"),
    (_cp(r'apache2\.conf$|httpd\.conf$'), "Apache 配置暴露"),
    (_cp(r'\.crt$|\.cert$|\.ca-bundle$'), "SSL 证书泄露"),
    (_cp(r'\.log$|debug\.log|error\.log|access\.log'), "日志文件泄露"),
    (_cp(r'db\.json$|database\.json$|firebase\.json$'), "数据库配置泄露"),
    (_cp(r'credentials\.(?:json|yml|yaml|xml|ini)'), "凭据文件泄露"),
    (_cp(r'secret[s]?\.(?:yml|yaml|json|env)'), "密钥文件泄露"),
    (_cp(r'/graphql'), "GraphQL 端点发现"),
    (_cp(r'/swagger\.json$|/swagger\.yaml$|/openapi\.json$'), "API 文档泄露"),
    (_cp(r'/api-docs|/apidocs|/swagger-ui'), "API 文档界面暴露"),
    (_cp(r'/actuator/'), "Spring Boot Actuator 暴露"),
    (_cp(r'/druid/'), "Alibaba Druid 监控暴露"),
]

MEDIUM_PATTERNS = [
    (_cp(r'debug|test|staging|dev|development|sandbox|demo|beta'), "非生产环境"),
    (_cp(r'phpinfo|info\.php|test\.php|probe\.php'), "信息/测试文件泄露"),
    (_cp(r'api/v\d|graphql|swagger|openapi|rest'), "API 接口发现"),
    (_cp(r'actuator|health|metrics|info|env|mappings'), "Spring Actuator 端点发现"),
    (_cp(r'X-Powered-By'), "服务端技术披露"),
    (_cp(r'Server:'), "服务器头信息泄露"),
    (_cp(r'crossdomain\.xml|clientaccesspolicy\.xml'), "跨域策略文件泄露"),
    (_cp(r'robots\.txt'), "robots.txt 可访问"),
    (_cp(r'/vendor/'), "Vendor 目录暴露"),
    (_cp(r'/node_modules/'), "Node 模块目录暴露"),
    (_cp(r'/bower_components/'), "Bower 组件目录暴露"),
    (_cp(r'CHANGELOG\.md$|CHANGELOG\.txt$|CHANGES\.md$'), "变更日志文件泄露"),
    (_cp(r'README\.md$|README\.txt$'), "说明文件泄露"),
    (_cp(r'LICENSE\.txt$|LICENSE\.md$|LICENCE$'), "许可证文件泄露"),
    (_cp(r'\.listing$'), "目录列表文件泄露"),
    (_cp(r'/\.idea/'), "IntelliJ IDEA 项目配置泄露"),
    (_cp(r'/\.vscode/'), "VS Code 工作区配置泄露"),
    (_cp(r'\.project$|\.classpath$'), "Eclipse 项目文件泄露"),
    (_cp(r'/\.well-known/'), ".well-known 目录发现"),
    (_cp(r'CONGRATULATION|HACKED|OWNED|DEFACED'), "网站被篡改"),
]

LOW_PATTERNS = [
    (_cp(r'<!--.*?-->'), "HTML 注释含敏感信息"),
    (_cp(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'), "邮箱地址泄露"),
    (_cp(r'hidden.*?input'), "隐藏表单字段发现"),
    (_cp(r'version\s*[:=]\s*\d+\.\d+'), "版本号披露"),
    (_cp(r'tel\s*[:=]\s*[+\d]'), "电话号码泄露"),
    (_cp(r'<!--\s*(?:TODO|FIXME|HACK|XXX|BUG|OPTIMIZE)'), "开发者注释含待办标记"),
    (_cp(r'console\.(?:log|warn|error|debug|info)\s*\('), "控制台调试输出残留"),
    (_cp(r'\.(?:ascx|asbx|asmx|ashx|axd|cshtml|vbhtml)$'), "ASP.NET 处理程序暴露"),
    (_cp(r'oracle\.xml\.jaxb'), "Oracle JAXB 命名空间暴露"),
    (_cp(r'xmlns'), "XML 命名空间泄露"),
]


def assess_url_finding(path: str, status: int, content_type: str = "") -> tuple:
    """评估 URL 路径和响应的风险等级"""
    if status == 200:
        for pattern, desc in CRITICAL_PATTERNS:
            if pattern.search(path) or (content_type and pattern.search(content_type)):
                return Severity.CRITICAL, desc
        for pattern, desc in HIGH_PATTERNS:
            if pattern.search(path):
                return Severity.HIGH, desc
        for pattern, desc in MEDIUM_PATTERNS:
            if pattern.search(path):
                return Severity.MEDIUM, desc
        for pattern, desc in LOW_PATTERNS:
            if pattern.search(path):
                return Severity.LOW, desc
    elif status in (301, 302, 307, 308):
        return Severity.INFO, f"重定向 ({status})"
    elif status == 401:
        return Severity.MEDIUM, "需认证 (受保护资源)"
    elif status == 403:
        return Severity.MEDIUM, "禁止访问 (受保护资源)"
    elif status == 405:
        return Severity.LOW, "方法不允许 (有效端点)"
    elif status >= 500:
        return Severity.MEDIUM, "服务端错误 (潜在漏洞)"
    return Severity.INFO, f"HTTP {status}"


def assess_content_finding(finding_type: str, detail: str) -> tuple:
    """评估内容分析的发现风险等级"""
    critical_kw = [
        "硬编码密码", "api 密钥", "api key", "私钥", "private key",
        "数据库连接", "db connection", "git 仓库", "git repository",
        "环境变量", ".env", "数据库导出", "dump", "phpinfo",
        "连接字符串", "connection string", "密码文件", "jwt", "token",
        "aws access key", "stripe", "私钥泄露", "凭据", "credential",
        "terraform state",
    ]
    high_kw = [
        "备份文件", "backup", "配置文件暴露", "config file exposed",
        "后台管理", "admin panel", "目录浏览", "directory listing",
        "sql 导出", "sql dump", "php 信息", "docker",
        "graphql", "swagger", "openapi", "actuator",
        "nginx", "apache", "ssl", "certificate", "log file",
    ]
    medium_kw = [
        "调试端点", "debug endpoint", "测试环境", "staging", "test env",
        "版本披露", "version disclosure", "api 接口", "api endpoint",
        "actuator", "vendor", "node_modules", "readme", "changelog",
    ]
    low_kw = [
        "html 注释", "html comment", "邮箱", "email",
        "隐藏表单", "hidden form", "隐藏字段", "console",
        "developer comment",
    ]

    ftype_lower = finding_type.lower()
    detail_lower = detail.lower()

    for kw in critical_kw:
        if kw in ftype_lower or kw in detail_lower:
            return Severity.CRITICAL, detail
    for kw in high_kw:
        if kw in ftype_lower or kw in detail_lower:
            return Severity.HIGH, detail
    for kw in medium_kw:
        if kw in ftype_lower or kw in detail_lower:
            return Severity.MEDIUM, detail
    for kw in low_kw:
        if kw in ftype_lower or kw in detail_lower:
            return Severity.LOW, detail
    return Severity.INFO, detail


# ── Port risk assessment ──

CRITICAL_PORTS = {
    23: "Telnet — 明文传输, 可嗅探",
    135: "RPC — 历史漏洞多",
    139: "NetBIOS — 信息泄露/远程攻击",
    445: "SMB — 勒索软件常用入口",
    1433: "MSSQL — 数据库暴露, 可爆破",
    2375: "Docker API — 未授权容器执行",
    2376: "Docker TLS — 可能配置错误",
    3306: "MySQL — 数据库直接暴露",
    3389: "RDP — 爆破目标",
    5432: "PostgreSQL — 数据库直接暴露",
    6379: "Redis — 未授权访问, WebShell 风险",
    27017: "MongoDB — 未授权访问, 数据泄露",
    27018: "MongoDB — 分片服务器暴露",
}

HIGH_PORTS = {
    21: "FTP — 可匿名登录",
    22: "SSH — 爆破目标",
    25: "SMTP — 邮件伪造/垃圾邮件",
    53: "DNS — DNS 隧道/区域传输",
    110: "POP3 — 明文邮件协议",
    143: "IMAP — 邮件协议",
    389: "LDAP — 目录服务",
    873: "rsync — 未授权文件同步",
    1080: "SOCKS 代理 — 滥用风险",
    1521: "Oracle DB — 数据库暴露",
    2049: "NFS — 网络文件系统",
    3128: "Squid — 代理服务",
    4443: "HTTPS 备用端口 — 可能为管理面板",
    4848: "GlassFish — 应用服务器",
    5601: "Kibana — 日志可视化",
    5672: "RabbitMQ — 消息队列",
    5900: "VNC — 远程控制",
    5984: "CouchDB — 文档数据库",
    5985: "WinRM HTTP — 远程管理",
    5986: "WinRM HTTPS — 远程管理",
    6443: "K8s API — 容器编排",
    7001: "WebLogic — 历史 RCE 漏洞多",
    7002: "WebLogic SSL — 历史漏洞多",
    7474: "Neo4j — 图数据库",
    8009: "AJP — Ghostcat 漏洞 (CVE-2020-1938)",
    8080: "HTTP 代理 — 常见管理面板",
    8089: "Splunk — 日志平台",
    8443: "HTTPS 备用 — 管理面板",
    9000: "PHP-FPM — FastCGI",
    9090: "Cockpit — 服务器管理",
    9200: "Elasticsearch — 未授权 RCE 风险",
    9300: "Elasticsearch — 节点通信",
    10000: "Webmin — 服务器管理面板",
    11211: "Memcached — UDP 放大攻击",
    15672: "RabbitMQ 管理 — 消息队列面板",
    50070: "Hadoop — 大数据平台",
}

MEDIUM_PORTS = {
    80: "HTTP — Web 服务",
    443: "HTTPS — 加密 Web 服务",
    554: "RTSP — 流媒体协议",
    1723: "PPTP — VPN 协议",
    3000: "HTTP 备用 — 开发服务器 (Node/Rails/React)",
    4000: "HTTP 备用 — 开发服务器",
    5000: "HTTP 备用 — 开发/API (Flask/Docker)",
    8000: "HTTP 备用 — 备选 Web 端口",
    8081: "HTTP 备用 — 备选 Web 端口",
    8888: "HTTP 备用 — 备选 Web 端口",
    9090: "HTTP 备用 — 管理端口",
    9443: "HTTPS 备用 — 备选 SSL 端口",
}


def assess_port_finding(port: int, banner: str) -> tuple:
    """评估端口开放的风险等级"""
    if port in CRITICAL_PORTS:
        return Severity.CRITICAL, CRITICAL_PORTS[port]
    if port in HIGH_PORTS:
        return Severity.HIGH, HIGH_PORTS[port]
    if port in MEDIUM_PORTS:
        return Severity.MEDIUM, MEDIUM_PORTS[port]
    bl = banner.lower()
    if "unauthorized" in bl or "anonymous" in bl or "root" in bl:
        return Severity.HIGH, f"端口 {port} — 可疑 Banner: {banner[:60]}"
    if "welcome" in bl and any(kw in bl for kw in ("ssh", "ftp", "telnet", "rdp")):
        return Severity.HIGH, f"端口 {port} — 含 Welcome 的服务 Banner: {banner[:60]}"
    return Severity.INFO, f"端口 {port} 开放 — 未知服务"
