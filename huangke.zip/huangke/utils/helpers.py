"""URL parsing and general utility functions."""

from urllib.parse import urlparse, urljoin


def normalize_url(url: str) -> str:
    """Ensure URL has scheme and ends with a single slash."""
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    parsed = urlparse(url)
    base = f"{parsed.scheme}://{parsed.netloc}"
    path = parsed.path or "/"
    if not path.endswith("/"):
        path += "/"
    return base + path


def join_url(base: str, path: str) -> str:
    """Safely join a base URL with a relative path."""
    if not base.endswith("/"):
        base += "/"
    path = path.lstrip("/")
    return urljoin(base, path)


def get_host(url: str) -> str:
    """Extract hostname from URL."""
    return urlparse(url).netloc


def is_same_host(url: str, base_url: str) -> bool:
    """Check if URL belongs to the same host."""
    return get_host(url) == get_host(base_url)


def extract_paths_from_html(html: str, base_url: str) -> list[str]:
    """Extract relative paths from href/src attributes in HTML."""
    import re
    paths = set()
    for match in re.finditer(r'(?:href|src)=["\']([^"\']+)["\']', html, re.I):
        href = match.group(1)
        if href.startswith(("http://", "https://")):
            if is_same_host(href, base_url):
                paths.add(urlparse(href).path)
        elif href.startswith("/") or href.startswith("./") or href.startswith("../"):
            paths.add(urlparse(urljoin(base_url, href)).path)
        elif not href.startswith(("#", "javascript:", "mailto:", "data:")):
            paths.add("/" + href)
    return sorted(paths)


def strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences from string."""
    import re
    return re.sub(r'\x1b\[[0-9;]*m', '', text)


# ── Service detection for discovered paths ──

SERVICE_PATTERNS: dict[str, list[str]] = {
    "WordPress": ["wp-admin", "wp-content", "wp-includes", "wp-login", "wp-json", "xmlrpc"],
    "Joomla": ["administrator", "components", "modules", "plugins", "templates", "language"],
    "Drupal": ["sites", "modules", "profiles", "themes", "misc", "includes", "scripts"],
    "Magento": ["skin", "media", "app", "var", "lib", "pub"],
    "Shopify": ["admin", "api", "collections", "products", "cart", "checkout"],
    "Laravel": ["artisan", "storage", "bootstrap", "vendor", "resources", "routes"],
    "Django": ["admin", "static", "media", "api", "auth", "accounts"],
    "Flask": ["static", "api", "login", "admin"],
    "Spring Boot": ["actuator", "api", "swagger-ui", "v2", "v3"],
    "Node.js/Express": ["api", "static", "images", "uploads", "socket.io"],
    "ASP.NET": ["web.config", "bin", "App_Data", "App_Code", "App_Start"],
    "Ruby on Rails": ["assets", "system", "uploads", "rails", "active_storage"],
    "phpMyAdmin": ["phpmyadmin", "pma", "adminer"],
    "Jenkins": ["jenkins", "job", "jobs", "plugin", "cli"],
    "Docker": ["docker", "registry", "v2", "v1"],
    "Kubernetes": ["api", "apis", "healthz", "livez", "readyz", "metrics", "openapi"],
    "GitLab": ["gitlab", "api/v4", "api/v3", "help", "explore"],
    "Grafana": ["grafana", "api/dashboards", "api/search", "login", "d"],
    "Kibana": ["kibana", "api/status", "app/kibana"],
    "Prometheus": ["prometheus", "api/v1", "metrics", "targets", "alerts"],
    "Elasticsearch": ["_search", "_cat", "_cluster", "_nodes", "_mapping"],
    "RabbitMQ": ["rabbitmq", "api/queues", "api/exchanges", "api/bindings"],
    "Redis": ["redis", "info", "cluster"],
    "REST API": ["api/v1", "api/v2", "api/v3", "swagger", "openapi", "api-docs"],
    "GraphQL": ["graphql", "graphiql", "playground"],
    "WebSocket": ["ws", "wss", "socket.io", "sockjs"],
    "后台管理": ["admin", "administrator", "dashboard", "panel", "cp", "manager"],
    "文件管理": ["filemanager", "files", "uploads", "download", "backup"],
    "登录页面": ["login", "signin", "auth", "oauth", "sso", "cas"],
    "开发者门户": ["dev", "developers", "api", "docs", "documentation"],
    "邮件服务": ["mail", "webmail", "roundcube", "squirrelmail", "rainloop"],
    "数据库管理": ["phpmyadmin", "adminer", "phpPgAdmin", "phpldapadmin", "sql"],
    "监控系统": ["monitor", "status", "health", "metrics", "stats", "prometheus", "grafana"],
}


def detect_service(path: str) -> str:
    """Detect the likely service/framework from a URL path."""
    path_lower = path.lower().strip("/")
    for service, patterns in SERVICE_PATTERNS.items():
        for pattern in patterns:
            if path_lower.startswith(pattern.lower()) or f"/{pattern.lower()}" in f"/{path_lower}":
                return service
    return ""
