"""
黄客联盟 · Web 控制面板 v3.0
HuangKe Alliance — Web Dashboard Backend
REST API | WebSocket | 信息收集 | 流式输出
"""

import asyncio
import hashlib
import json
import os
import secrets
import time
import uuid
import webbrowser
from pathlib import Path
from typing import Optional

import aiohttp
from aiohttp import web

from ..core.engine import EngineConfig, HTTPEngine
from ..core.scanner import DirectoryScanner, ScanConfig
from ..core.fingerprint import WebFingerprinter
from ..core.analyzer import ContentAnalyzer
from ..core.port_scanner import PortScanner, TOP_PORTS
from ..data.wordlists import load_wordlist, load_default_wordlist
from ..output.json_out import export_json
from ..output.html_out import render_html
from ..output.csv_out import export_csv
from ..output.md_out import export_markdown

_TEMPLATE_DIR = Path(__file__).parent

# Simple token storage for login
_AUTH_TOKENS: dict[str, str] = {}  # token -> username
_VALID_CREDENTIALS = {
    "admin": "huangke",
    "hk": "huangke2024",
}


# ═══════════════════════════════════════════════
# Authentication
# ═══════════════════════════════════════════════

def _check_auth(request: web.Request) -> bool:
    """Check Authorization header for valid token."""
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:]
        return token in _AUTH_TOKENS
    return False


def _require_auth(handler):
    """Decorator to require authentication."""
    async def wrapper(request: web.Request):
        if not _check_auth(request):
            return web.json_response({"error": "未授权访问"}, status=401)
        return await handler(request)
    return wrapper


# ═══════════════════════════════════════════════
# Scan Task Management
# ═══════════════════════════════════════════════

class ScanTask:
    def __init__(self, task_id: str, url: str, scan_type: str, options: dict):
        self.id = task_id
        self.url = url
        self.type = scan_type
        self.options = options
        self.status = "pending"
        self.progress = 0
        self.total = 0
        self.message = "等待开始..."
        self.result = None
        self.error = None
        self.start_time = None
        self.end_time = None
        self.elapsed = 0
        self._ws_clients: list[web.WebSocketResponse] = []
        self._sse_responses: list[web.StreamResponse] = []
        self._logs: list[dict] = []  # Streaming logs

    def to_dict(self):
        return {
            "id": self.id,
            "url": self.url,
            "type": self.type,
            "status": self.status,
            "progress": self.progress,
            "total": self.total,
            "message": self.message,
            "elapsed": round(time.time() - self.start_time, 1) if self.start_time else 0,
            "error": self.error,
            "start_time": self.start_time,
        }

    async def log(self, level: str, text: str):
        """Add streaming log entry and broadcast."""
        entry = {
            "time": time.strftime("%H:%M:%S"),
            "level": level,
            "text": text,
        }
        self._logs.append(entry)
        await self.broadcast({"action": "log", "entry": entry})

    async def broadcast(self, data: dict):
        """Broadcast data to all connected clients (WS + SSE)."""
        payload = {"action": "state", **data} if "action" not in data else data
        dead_ws = []
        for ws in self._ws_clients:
            try:
                await ws.send_json(payload)
            except Exception:
                dead_ws.append(ws)
        for ws in dead_ws:
            self._ws_clients.remove(ws)

        dead_sse = []
        for sse in self._sse_responses:
            try:
                await sse.write(("data: " + json.dumps(payload, ensure_ascii=False) + "\n\n").encode("utf-8"))
            except Exception:
                dead_sse.append(sse)
        for sse in dead_sse:
            self._sse_responses.remove(sse)

    def add_ws(self, ws: web.WebSocketResponse):
        self._ws_clients.append(ws)

    def remove_ws(self, ws: web.WebSocketResponse):
        if ws in self._ws_clients:
            self._ws_clients.remove(ws)

    def add_sse(self, sse: web.StreamResponse):
        self._sse_responses.append(sse)

    def remove_sse(self, sse: web.StreamResponse):
        if sse in self._sse_responses:
            self._sse_responses.remove(sse)


class ScanManager:
    def __init__(self):
        self._tasks: dict[str, ScanTask] = {}

    def create(self, url: str, scan_type: str, options: dict) -> ScanTask:
        tid = uuid.uuid4().hex[:12]
        task = ScanTask(tid, url, scan_type, options)
        self._tasks[tid] = task
        return task

    def get(self, tid: str) -> Optional[ScanTask]:
        return self._tasks.get(tid)

    def list_all(self) -> list[ScanTask]:
        return sorted(self._tasks.values(), key=lambda t: t.start_time or "", reverse=True)

    def recent(self, n=20) -> list[ScanTask]:
        return self.list_all()[:n]

    def delete(self, tid: str) -> bool:
        if tid in self._tasks:
            del self._tasks[tid]
            return True
        return False


_scan_manager = ScanManager()


# ═══════════════════════════════════════════════
# Scan Executor — 流式输出支持
# ═══════════════════════════════════════════════

async def _execute_scan(task: ScanTask):
    task.status = "running"
    task.start_time = time.time()
    task.message = "正在初始化引擎..."
    await task.log("info", "扫描引擎初始化中...")
    errors = []

    try:
        opts = task.options
        cfg = EngineConfig(
            timeout=opts.get("timeout", 10),
            delay=opts.get("delay", 0),
            max_concurrency=opts.get("threads", 30),
            proxy=opts.get("proxy"),
            user_agent=opts.get("ua"),
            verify_ssl=not opts.get("no_verify", False),
        )
        wl = _load_wl(opts.get("wordlist", "default"))

        async with HTTPEngine(cfg) as eng:
            result = {}

            # Phase 1: Directory scan
            if task.type in ("scan", "full"):
                task.message = f"目录扫描中... 词表 {len(wl)} 条"
                await task.log("info", f"开始目录扫描，词表 {len(wl)} 条")
                await task.broadcast(task.to_dict())
                try:
                    scfg = ScanConfig(
                        recursive=opts.get("recursive", False),
                        max_depth=opts.get("depth", 2),
                    )
                    scanner = DirectoryScanner(eng, task.url, wl, config=scfg)
                    await scanner.scan()
                    result["scan_results"] = scanner.results
                    task.progress = len(scanner.results)
                    task.total = len(wl)
                    task.message = f"目录扫描完成 — 发现 {len(scanner.results)} 个端点"
                    await task.log("success", f"目录扫描完成，发现 {len(scanner.results)} 个端点")
                    for r in scanner.results[:20]:
                        await task.log("data", f"  [{r.status}] {r.path} ({r.severity.label})")
                except Exception as e:
                    errors.append(f"目录扫描: {e}")
                    task.message = f"目录扫描失败: {e}"
                    await task.log("error", f"目录扫描失败: {e}")
                    result["scan_results"] = []

            # Phase 2: Port scan
            if task.type in ("port", "full") and not opts.get("no_port"):
                task.message = "端口扫描中..."
                await task.log("info", "开始端口扫描...")
                await task.broadcast(task.to_dict())
                try:
                    from urllib.parse import urlparse
                    host = urlparse(task.url if "://" in task.url else f"https://{task.url}").hostname or task.url
                    ps = PortScanner(host, ports=TOP_PORTS, timeout=min(opts.get("timeout", 10) * 0.3, 2.0))
                    await ps.scan()
                    result["port_results"] = ps.results
                    task.message = f"端口扫描完成 — {len(ps.results)} 个端口开放"
                    await task.log("success", f"端口扫描完成，发现 {len(ps.results)} 个开放端口")
                    for r in ps.results[:10]:
                        await task.log("data", f"  端口 {r.port}/{r.service} — {r.severity.label}")
                except Exception as e:
                    errors.append(f"端口扫描: {e}")
                    await task.log("error", f"端口扫描失败: {e}")
                    result["port_results"] = []

            # Phase 3: Fingerprint
            if task.type in ("finger", "full") and not opts.get("no_finger", False):
                task.message = "指纹识别中..."
                await task.log("info", "开始 Web 指纹识别...")
                await task.broadcast(task.to_dict())
                try:
                    fp = WebFingerprinter(eng, task.url)
                    fp_info = await fp.fingerprint()
                    result["fingerprint"] = fp_info
                    task.message = f"指纹识别完成 — {len(fp_info.technologies)} 项技术"
                    await task.log("success", f"指纹识别完成，发现 {len(fp_info.technologies)} 项技术")
                    for t in fp_info.technologies[:10]:
                        await task.log("data", f"  [{t.category}] {t.name} ({t.confidence})")
                    if fp_info.waf:
                        await task.log("warn", f"检测到 WAF: {', '.join(w.name for w in fp_info.waf)}")
                except Exception as e:
                    errors.append(f"指纹识别: {e}")
                    await task.log("error", f"指纹识别失败: {e}")

            # Phase 4: Content analysis
            if task.type == "full" and not opts.get("no_analyze"):
                task.message = "内容分析中..."
                await task.log("info", "开始页面内容分析...")
                await task.broadcast(task.to_dict())
                try:
                    urls = [task.url]
                    for r in result.get("scan_results", []):
                        if r.status == 200 and r.severity.score >= 3:
                            urls.append(r.url)
                    uniq = list(dict.fromkeys(urls))
                    az = ContentAnalyzer(eng, task.url)
                    await az.analyze_urls(uniq[:50])
                    result["content_findings"] = az.all_findings()
                    task.message = f"内容分析完成 — {len(result['content_findings'])} 项发现"
                    await task.log("success", f"内容分析完成，发现 {len(result['content_findings'])} 项风险")
                    for f in result["content_findings"][:10]:
                        await task.log("data", f"  [{f.severity.label}] {f.finding_type}: {f.detail[:60]}")
                except Exception as e:
                    errors.append(f"内容分析: {e}")
                    await task.log("error", f"内容分析失败: {e}")
                    result["content_findings"] = []

            task.result = result
            task.status = "completed"
            suffix = f" (部分阶段失败: {'; '.join(errors)})" if errors else ""
            task.message = "扫描完成" + suffix
            task.end_time = time.time()
            task.elapsed = task.end_time - task.start_time
            await task.log("success", f"扫描完成，耗时 {task.elapsed:.1f}s")

    except Exception as e:
        task.status = "failed"
        task.error = str(e)
        task.message = f"扫描失败: {e}"
        task.end_time = time.time()
        await task.log("error", f"扫描失败: {e}")

    await task.broadcast(task.to_dict())


def _load_wl(arg: str) -> list:
    if arg in ("default", "common", "sensitive", "api", "tech", "vuln", "backup", "admin"):
        return load_default_wordlist() if arg == "default" else load_wordlist(arg)
    return load_wordlist(arg)


# ═══════════════════════════════════════════════
# 信息收集执行器
# ═══════════════════════════════════════════════

async def _execute_info_gathering(task: ScanTask):
    """Execute information gathering with streaming output."""
    task.status = "running"
    task.start_time = time.time()
    task.message = "正在收集目标信息..."
    await task.log("info", f"开始信息收集: {task.url}")

    try:
        from ..info.gather import InfoGatherer
        from urllib.parse import urlparse

        url = task.url
        domain = url
        if "://" in domain:
            domain = domain.split("://", 1)[1].split("/")[0]

        gatherer = InfoGatherer(url, timeout=10)
        result = await gatherer.gather_all()

        if result.dns:
            await task.log("success", f"DNS 查询完成")
            if result.dns.a_records:
                await task.log("data", f"  A 记录: {', '.join(result.dns.a_records)}")
            if result.dns.mx_records:
                await task.log("data", f"  MX 记录: {', '.join(result.dns.mx_records)}")
            if result.dns.ns_records:
                await task.log("data", f"  NS 记录: {', '.join(result.dns.ns_records)}")

        if result.ssl:
            await task.log("success", f"SSL 证书检查完成")
            if result.ssl.issuer:
                await task.log("data", f"  颁发者: {result.ssl.issuer[:80]}")
            if result.ssl.days_remaining:
                await task.log("data", f"  过期: {result.ssl.days_remaining}天后")

        if result.subdomains:
            await task.log("success", f"子域名枚举完成 — 发现 {result.subdomains.total_found} 个")
            for sub, ip in sorted(result.subdomains.subdomains.items())[:20]:
                await task.log("data", f"  {sub}.{domain} → {ip}")

        task.result = {"info_result": result.to_dict()}
        task.status = "completed"
        task.message = "信息收集完成"
        task.end_time = time.time()
        task.elapsed = task.end_time - task.start_time
        await task.log("success", f"信息收集完成，耗时 {task.elapsed:.1f}s")

    except Exception as e:
        task.status = "failed"
        task.error = str(e)
        task.message = f"信息收集失败: {e}"
        await task.log("error", f"信息收集失败: {e}")

    await task.broadcast(task.to_dict())


# ═══════════════════════════════════════════════
# Auth Routes
# ═══════════════════════════════════════════════

async def login_handler(request: web.Request) -> web.Response:
    try:
        data = await request.json()
    except Exception:
        return web.json_response({"error": "无效的请求体"}, status=400)

    username = data.get("username", "")
    password = data.get("password", "")

    if _VALID_CREDENTIALS.get(username) == password:
        token = secrets.token_hex(32)
        _AUTH_TOKENS[token] = username
        return web.json_response({
            "token": token,
            "username": username,
            "message": "登录成功",
        })

    return web.json_response({"error": "用户名或密码错误"}, status=401)


# ═══════════════════════════════════════════════
# Web Routes
# ═══════════════════════════════════════════════

async def index_handler(request: web.Request) -> web.Response:
    html_path = _TEMPLATE_DIR / "dashboard.html"
    if html_path.exists():
        return web.FileResponse(html_path)
    return web.Response(text="Dashboard not found", status=404)


async def api_status(request: web.Request) -> web.Response:
    tasks = _scan_manager.list_all()
    running = sum(1 for t in tasks if t.status in ("pending", "running"))
    return web.json_response({
        "version": "3.0.0",
        "name": "黄客联盟 · 渗透测试工具箱",
        "author": "黄客联盟 (HuangKe Alliance)",
        "tasks_total": len(tasks),
        "tasks_running": running,
        "tasks_completed": sum(1 for t in tasks if t.status == "completed"),
        "tasks_failed": sum(1 for t in tasks if t.status == "failed"),
        "uptime": time.time(),
    })


async def api_scan_list(request: web.Request) -> web.Response:
    tasks = _scan_manager.recent(50)
    return web.json_response([t.to_dict() for t in tasks])


async def api_scan_start(request: web.Request) -> web.Response:
    try:
        data = await request.json()
    except Exception:
        return web.json_response({"error": "无效的 JSON 请求体"}, status=400)

    url = data.get("url", "").strip()
    if not url:
        return web.json_response({"error": "URL 不能为空"}, status=400)
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    scan_type = data.get("type", "scan")
    if scan_type not in ("scan", "full", "port", "finger", "info"):
        return web.json_response({"error": f"无效的扫描类型: {scan_type}"}, status=400)

    task = _scan_manager.create(url, scan_type, data)

    if scan_type == "info":
        asyncio.ensure_future(_execute_info_gathering(task))
    else:
        asyncio.ensure_future(_execute_scan(task))

    return web.json_response(task.to_dict(), status=201)


async def api_scan_detail(request: web.Request) -> web.Response:
    tid = request.match_info["id"]
    task = _scan_manager.get(tid)
    if not task:
        return web.json_response({"error": "任务不存在"}, status=404)
    d = task.to_dict()
    if task.result:
        sr = task.result.get("scan_results", [])
        fi = task.result.get("fingerprint")
        cf = task.result.get("content_findings", [])
        pr = task.result.get("port_results", [])
        ir = task.result.get("info_result")
        d["results_summary"] = {
            "endpoints": len(sr),
            "open_ports": len(pr),
            "technologies": len(fi.technologies) if fi else 0,
            "waf": [w.name for w in fi.waf] if fi else [],
            "cdn": [c.name for c in fi.cdn] if fi else [],
            "findings": len(cf),
            "page_title": fi.page_title if fi else "",
            "server": fi.server if fi else "",
            "info": ir is not None,
        }
    return web.json_response(d)


async def api_scan_logs(request: web.Request) -> web.Response:
    tid = request.match_info["id"]
    task = _scan_manager.get(tid)
    if not task:
        return web.json_response({"error": "任务不存在"}, status=404)
    return web.json_response({"logs": task._logs})


async def api_scan_results(request: web.Request) -> web.Response:
    tid = request.match_info["id"]
    task = _scan_manager.get(tid)
    if not task:
        return web.json_response({"error": "任务不存在"}, status=404)
    if not task.result:
        return web.json_response({"error": "扫描尚未完成"}, status=400)

    sr = task.result.get("scan_results", [])
    fi = task.result.get("fingerprint")
    cf = task.result.get("content_findings", [])
    pr = task.result.get("port_results", [])
    ir = task.result.get("info_result")

    resp = {
        "scan_results": [
            {
                "path": r.path, "url": r.url, "status": r.status,
                "content_type": r.content_type, "content_length": r.content_length,
                "severity": r.severity.label, "risk_desc": r.risk_desc,
                "body_preview": r.body_preview[:200] if r.body_preview else "",
                "service": getattr(r, "service", ""),
            }
            for r in sorted(sr, key=lambda x: x.severity.score, reverse=True)
        ],
        "port_results": [
            {"port": r.port, "service": r.service, "state": r.state,
             "banner": r.banner, "severity": r.severity.label, "risk_desc": r.risk_desc}
            for r in sorted(pr, key=lambda x: x.severity.score, reverse=True)
        ] if pr else [],
        "fingerprint": {
            "server": fi.server if fi else "",
            "page_title": fi.page_title if fi else "",
            "powered_by": fi.powered_by if fi else "",
            "generator": fi.generator if fi else "",
            "ip": fi.ip if fi else "",
            "technologies": [
                {"category": t.category, "name": t.name, "confidence": t.confidence, "evidence": t.evidence}
                for t in fi.technologies
            ] if fi else [],
            "waf": [{"name": w.name, "evidence": w.evidence} for w in fi.waf] if fi else [],
            "cdn": [{"name": c.name, "evidence": c.evidence} for c in fi.cdn] if fi and hasattr(fi, "cdn") else [],
            "security_headers": fi.security_headers if fi else {},
        },
        "content_findings": [
            {"type": f.finding_type, "detail": f.detail, "severity": f.severity.label, "url": f.url}
            for f in sorted(cf, key=lambda x: x.severity.score, reverse=True)
        ] if cf else [],
        "info_result": ir,
    }
    return web.json_response(resp)


async def api_scan_export(request: web.Request) -> web.Response:
    tid = request.match_info["id"]
    task = _scan_manager.get(tid)
    if not task or not task.result:
        return web.json_response({"error": "结果不可用"}, status=404)

    fmt = request.query.get("format", "json")
    if fmt not in ("json", "html", "csv", "md"):
        return web.json_response({"error": f"不支持的格式: {fmt}"}, status=400)

    sr = task.result.get("scan_results", [])
    fi = task.result.get("fingerprint")
    cf = task.result.get("content_findings", [])

    try:
        if fmt == "html":
            content = render_html(sr, fi, cf, task.url, task.elapsed)
            return web.Response(text=content, content_type="text/html; charset=utf-8")
        elif fmt == "csv":
            content = export_csv(sr, fi, cf, task.url)
            return web.Response(text=content, content_type="text/csv; charset=utf-8")
        elif fmt == "md":
            content = export_markdown(sr, fi, cf, task.url, task.elapsed)
            return web.Response(text=content, content_type="text/markdown; charset=utf-8")
        else:
            content = export_json(sr, fi, cf, task.url, task.elapsed)
            return web.Response(text=content, content_type="application/json; charset=utf-8")
    except Exception as e:
        return web.json_response({"error": f"导出失败: {e}"}, status=500)


async def api_scan_delete(request: web.Request) -> web.Response:
    tid = request.match_info["id"]
    if _scan_manager.delete(tid):
        return web.json_response({"status": "deleted"})
    return web.json_response({"error": "任务不存在"}, status=404)


async def websocket_handler(request: web.Request) -> web.WebSocketResponse:
    tid = request.match_info["id"]
    task = _scan_manager.get(tid)
    if not task:
        return web.Response(text="Task not found", status=404)

    ws = web.WebSocketResponse()
    await ws.prepare(request)
    task.add_ws(ws)

    # Send current state and logs immediately
    await ws.send_json(task.to_dict())
    for log_entry in task._logs:
        await ws.send_json({"action": "log", "entry": log_entry})

    try:
        async for msg in ws:
            if msg.type == aiohttp.WSMsgType.TEXT:
                data = json.loads(msg.data)
                if data.get("action") == "ping":
                    await ws.send_json({"action": "pong"})
            elif msg.type == aiohttp.WSMsgType.ERROR:
                break
    finally:
        task.remove_ws(ws)
    return ws


# ── SSE Handler ──

async def sse_handler(request: web.Request) -> web.StreamResponse:
    tid = request.match_info["id"]
    task = _scan_manager.get(tid)
    if not task:
        return web.Response(text="Task not found", status=404)

    response = web.StreamResponse(
        status=200, reason="OK",
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Access-Control-Allow-Origin": "*",
        },
    )
    await response.prepare(request)
    task.add_sse(response)

    # Send current state and logs
    await response.write(("data: " + json.dumps({"action": "init", **task.to_dict()}, ensure_ascii=False) + "\n\n").encode("utf-8"))
    for log_entry in task._logs:
        await response.write(("data: " + json.dumps({"action": "log", "entry": log_entry}, ensure_ascii=False) + "\n\n").encode("utf-8"))

    try:
        while True:
            await asyncio.sleep(30)
            await response.write((": keepalive\n\n").encode("utf-8"))
    except (ConnectionResetError, ConnectionAbortedError):
        pass
    finally:
        task.remove_sse(response)
    return response


# ═══════════════════════════════════════════════
# App Factory
# ═══════════════════════════════════════════════

def create_app() -> web.Application:
    app = web.Application()
    app.router.add_get("/", index_handler)
    app.router.add_post("/api/login", login_handler)
    app.router.add_get("/api/status", api_status)
    app.router.add_get("/api/scans", api_scan_list)
    app.router.add_post("/api/scan", api_scan_start)
    app.router.add_get("/api/scan/{id}", api_scan_detail)
    app.router.add_get("/api/scan/{id}/logs", api_scan_logs)
    app.router.add_get("/api/scan/{id}/results", api_scan_results)
    app.router.add_get("/api/scan/{id}/export", api_scan_export)
    app.router.add_delete("/api/scan/{id}", api_scan_delete)
    app.router.add_get("/ws/{id}", websocket_handler)
    app.router.add_get("/sse/{id}", sse_handler)

    # Static files
    static_dir = _TEMPLATE_DIR / "static"
    if static_dir.exists():
        app.router.add_static("/static", static_dir)

    return app


async def start_web_server(host: str = "127.0.0.1", port: int = 8080, open_browser: bool = True):
    """启动黄客联盟 Web 控制面板"""
    app = create_app()
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host, port)

    url = f"http://{host}:{port}"
    try:
        await site.start()
    except OSError:
        for alt_port in range(8081, 8095):
            try:
                alt_site = web.TCPSite(runner, host, alt_port)
                await alt_site.start()
                url = f"http://{host}:{alt_port}"
                break
            except OSError:
                continue
        else:
            raise OSError(f"端口 {port}~8094 均被占用，无法启动 Web 服务")

    from ..output.console import console
    console.print(f"\n  [bold green]黄客联盟 Web 控制面板已启动[/bold green]")
    console.print(f"  地址: [bold cyan]{url}[/bold cyan]")
    console.print(f"  默认账号: [yellow]admin[/yellow]  密码: [yellow]huangke[/yellow]")
    console.print(f"  按 [bold red]Ctrl+C[/bold red] 停止服务\n")

    if open_browser:
        webbrowser.open(url)

    try:
        while True:
            await asyncio.sleep(3600)
    except asyncio.CancelledError:
        pass
    finally:
        await runner.cleanup()
