"""HTTP 安全头部分析 — 检测缺失/配置不当的安全响应头"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class HeaderFinding:
    header: str
    status: str  # "present" | "missing" | "weak"
    value: str = ""
    recommendation: str = ""
    severity: str = "info"  # "high" | "medium" | "low" | "info"


# Security headers to check with recommendations
SECURITY_HEADERS = {
    "Strict-Transport-Security": {
        "recommendation": "Add: Strict-Transport-Security: max-age=31536000; includeSubDomains",
        "severity": "medium",
        "check_weak": lambda v: "max-age=" in v,
    },
    "Content-Security-Policy": {
        "recommendation": "Add: Content-Security-Policy to prevent XSS attacks",
        "severity": "high",
        "check_weak": lambda v: "'unsafe-inline'" not in v and "'unsafe-eval'" not in v,
    },
    "X-Content-Type-Options": {
        "recommendation": "Add: X-Content-Type-Options: nosniff",
        "severity": "low",
        "check_weak": lambda v: "nosniff" in v,
    },
    "X-Frame-Options": {
        "recommendation": "Add: X-Frame-Options: DENY or SAMEORIGIN",
        "severity": "medium",
        "check_weak": lambda v: v.upper() in ("DENY", "SAMEORIGIN"),
    },
    "X-XSS-Protection": {
        "recommendation": "Add: X-XSS-Protection: 1; mode=block",
        "severity": "low",
        "check_weak": lambda v: "1" in v and "block" in v,
    },
    "Referrer-Policy": {
        "recommendation": "Add: Referrer-Policy: strict-origin-when-cross-origin",
        "severity": "low",
        "check_weak": lambda v: True,
    },
    "Permissions-Policy": {
        "recommendation": "Add: Permissions-Policy to restrict feature access",
        "severity": "low",
        "check_weak": lambda v: True,
    },
    "Access-Control-Allow-Origin": {
        "recommendation": "Avoid wide-open CORS: Access-Control-Allow-Origin: *",
        "severity": "medium",
        "check_weak": lambda v: v.strip() != "*",
    },
    "Set-Cookie": {
        "recommendation": "Ensure cookies have HttpOnly, Secure, SameSite attributes",
        "severity": "medium",
        "check_weak": lambda v: "HttpOnly" in v or "Secure" in v,
    },
}


class HeaderAnalyzer:
    """Analyze HTTP response headers for security misconfigurations."""

    def __init__(self, headers: dict):
        self.headers = {k.lower(): v for k, v in headers.items()}

    def analyze(self) -> list[HeaderFinding]:
        findings: list[HeaderFinding] = []
        for hdr_name, info in SECURITY_HEADERS.items():
            key = hdr_name.lower()
            value = self.headers.get(key, "")
            if not value:
                findings.append(HeaderFinding(
                    header=hdr_name,
                    status="missing",
                    recommendation=info["recommendation"],
                    severity=info["severity"],
                ))
            elif not info["check_weak"](value):
                findings.append(HeaderFinding(
                    header=hdr_name,
                    status="weak",
                    value=value[:200],
                    recommendation=info["recommendation"],
                    severity=info["severity"],
                ))
            else:
                findings.append(HeaderFinding(
                    header=hdr_name,
                    status="present",
                    value=value[:200],
                    severity="info",
                ))
        return findings

    def missing_count(self) -> int:
        return sum(1 for f in self.analyze() if f.status == "missing")

    def weak_count(self) -> int:
        return sum(1 for f in self.analyze() if f.status == "weak")
