"""
WHOIS 查询模块 — 域名/IP注册信息 (系统 whois 命令)
"""

import asyncio
import re
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class WhoisResult:
    domain: str
    raw: str = ""
    registrar: Optional[str] = None
    creation_date: Optional[str] = None
    expiration_date: Optional[str] = None
    updated_date: Optional[str] = None
    name_servers: list[str] = field(default_factory=list)
    org: Optional[str] = None
    country: Optional[str] = None
    emails: list[str] = field(default_factory=list)
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "domain": self.domain,
            "registrar": self.registrar,
            "creation_date": self.creation_date,
            "expiration_date": self.expiration_date,
            "updated_date": self.updated_date,
            "name_servers": self.name_servers,
            "org": self.org,
            "country": self.country,
            "emails": self.emails,
        }


class WhoisLookup:
    """Async WHOIS lookup using system `whois` command."""

    def __init__(self, timeout: float = 15.0):
        self.timeout = timeout

    async def lookup(self, domain: str) -> WhoisResult:
        domain = domain.strip().lower()
        result = WhoisResult(domain=domain)

        try:
            proc = await asyncio.create_subprocess_exec(
                "whois", domain,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=self.timeout
            )
            raw = stdout.decode("utf-8", errors="replace")

            if not raw.strip() or "No whois server" in raw:
                result.error = "No WHOIS information available"
                return result

            result.raw = raw[:5000]
            self._parse(raw, result)
        except asyncio.TimeoutError:
            result.error = "WHOIS lookup timed out"
        except FileNotFoundError:
            result.error = "whois command not found"
        except Exception as e:
            result.error = str(e)

        return result

    def _parse(self, raw: str, result: WhoisResult):
        patterns = {
            "registrar": [r"Registrar:\s*(.+)", r"registrar:\s*(.+)", r"Sponsoring Registrar:\s*(.+)"],
            "creation_date": [r"Creation Date:\s*(.+)", r"created:\s*(.+)", r"Domain Registration Date:\s*(.+)"],
            "expiration_date": [r"Expir(?:y|ation) Date:\s*(.+)", r"expire:\s*(.+)", r"paid-till:\s*(.+)"],
            "updated_date": [r"Updated Date:\s*(.+)", r"last-modified:\s*(.+)", r"changed:\s*(.+)"],
            "org": [r"OrgName:\s*(.+)", r"organisation:\s*(.+)", r"Organization:\s*(.+)", r"org:\s*(.+)"],
            "country": [r"Country:\s*(.+)", r"country:\s*(.+)"],
        }
        for field_name, p_list in patterns.items():
            for p in p_list:
                m = re.search(p, raw, re.I)
                if m:
                    val = m.group(1).strip()
                    setattr(result, field_name, val)
                    break

        ns_patterns = [r"Name Server:\s*(.+)", r"nserver:\s*(.+)", r"nameserver:\s*(.+)"]
        seen_ns = set()
        for p in ns_patterns:
            for m in re.finditer(p, raw, re.I):
                ns = m.group(1).strip().rstrip(".")
                if ns and ns not in seen_ns:
                    seen_ns.add(ns)
                    result.name_servers.append(ns)
            if result.name_servers:
                break

        email_p = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
        seen_emails = set()
        for m in email_p.finditer(raw):
            e = m.group(0)
            if e not in seen_emails:
                seen_emails.add(e)
                result.emails.append(e)
