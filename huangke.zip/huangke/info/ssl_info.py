"""
SSL/TLS 证书信息收集 — 证书链 | 颁发者 | 有效期 | SAN
"""

import asyncio
import ssl
import socket
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class SSLResult:
    domain: str
    issuer: str = ""
    subject: str = ""
    version: str = ""
    serial: str = ""
    valid_from: str = ""
    valid_to: str = ""
    days_remaining: int = 0
    san: list = field(default_factory=list)
    algorithm: str = ""
    fingerprint: str = ""
    tls_version: str = ""
    error: str = ""


class SSLInspector:
    """SSL/TLS 证书检查器"""

    def __init__(self, domain: str, timeout: float = 10.0, port: int = 443):
        self.domain = domain.lower().strip()
        # Remove scheme if present
        if "://" in self.domain:
            self.domain = self.domain.split("://", 1)[1].split("/")[0].split(":")[0]
        self.timeout = timeout
        self.port = port

    async def inspect(self) -> SSLResult:
        result = SSLResult(domain=self.domain)

        try:
            loop = asyncio.get_event_loop()

            def _get_ssl():
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                with socket.create_connection(
                    (self.domain, self.port), timeout=self.timeout
                ) as sock:
                    with ctx.wrap_socket(sock, server_hostname=self.domain) as ssock:
                        cert = ssock.getpeercert(binary_form=True)
                        cert_dict = ssock.getpeercert()
                        version = ssock.version()
                        cipher = ssock.cipher()
                        return cert, cert_dict, version, cipher

            cert_bin, cert_dict, tls_ver, cipher_info = await asyncio.wait_for(
                loop.run_in_executor(None, _get_ssl),
                timeout=self.timeout
            )

            result.tls_version = tls_ver or ""

            if cert_dict:
                # Issuer
                issuer_parts = []
                for part in cert_dict.get("issuer", []):
                    for key, val in part:
                        issuer_parts.append(f"{key}={val}")
                result.issuer = ", ".join(issuer_parts)

                # Subject
                subject_parts = []
                for part in cert_dict.get("subject", []):
                    for key, val in part:
                        subject_parts.append(f"{key}={val}")
                result.subject = ", ".join(subject_parts)

                # Validity
                valid_from = cert_dict.get("notBefore", "")
                valid_to = cert_dict.get("notAfter", "")
                result.valid_from = valid_from
                result.valid_to = valid_to

                # Days remaining
                try:
                    from datetime import timezone
                    if valid_to:
                        # Parse ASN1 time formats
                        if valid_to.endswith("Z"):
                            fmt = "%Y%m%d%H%M%SZ"
                            expiry = datetime.strptime(valid_to, fmt).replace(tzinfo=timezone.utc)
                            now = datetime.now(timezone.utc)
                            result.days_remaining = (expiry - now).days
                except Exception:
                    pass

                # SAN
                san_list = []
                for san_entry in cert_dict.get("subjectAltName", []):
                    san_list.append(f"{san_entry[0]}: {san_entry[1]}")
                result.san = san_list

                # Serial number
                result.serial = str(cert_dict.get("serialNumber", ""))

                # Algorithm
                result.algorithm = cert_dict.get("signatureAlgorithm", "")

            # Fingerprint
            if cert_bin:
                import hashlib
                result.fingerprint = hashlib.sha256(cert_bin).hexdigest()

        except Exception as e:
            result.error = str(e)

        return result

    def summary(self, result: SSLResult) -> dict:
        return {
            "domain": result.domain,
            "issuer": result.issuer,
            "days_remaining": result.days_remaining,
            "san_count": len(result.san),
            "tls_version": result.tls_version,
            "algorithm": result.algorithm,
        }
