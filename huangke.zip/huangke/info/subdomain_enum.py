"""
子域名枚举模块 — 常见子域名爆破 + DNS 解析验证
"""

import asyncio
import socket
from dataclasses import dataclass, field
from typing import Optional


# 常见子域名列表
COMMON_SUBDOMAINS = [
    "www", "mail", "admin", "api", "blog", "dev", "test", "stage", "staging",
    "beta", "demo", "shop", "store", "app", "m", "mobile", "web", "portal",
    "vpn", "remote", "ssh", "smtp", "pop3", "imap", "exchange", "owa",
    "cpanel", "whm", "webmail", "webdisk", "direct", "secure", "ssl",
    "git", "svn", "jenkins", "jira", "confluence", "wiki", "docs",
    "monitor", "status", "stats", "analytics", "tracking", "logs",
    "database", "db", "sql", "mysql", "redis", "mongo", "elastic",
    "cdn", "static", "assets", "media", "img", "images", "css", "js",
    "download", "uploads", "files", "backup", "backups", "old",
    "new", "test1", "test2", "dev1", "dev2", "stage1", "stage2",
    "sandbox", "playground", "lab", "internal", "corp", "office",
    "chat", "support", "help", "helpdesk", "service", "services",
    "dashboard", "panel", "control", "console", "manager", "adminpanel",
    "autodiscover", "lyncdiscover", "sip", "meet", "teams",
    "ns1", "ns2", "ns3", "dns1", "dns2", "mx1", "mx2",
    "ftp", "sftp", "transfer", "file", "cloud", "sync",
    "partner", "partners", "vendor", "vendors", "client", "clients",
    "calendar", "calendar", "contacts", "addressbook",
    "invoice", "invoices", "billing", "payment", "pay",
    "wholesale", "retail", "distributor",
    "recruit", "jobs", "career", "careers",
    "newsletter", "news", "announce",
    "forum", "community", "groups", "group",
    "survey", "poll", "register", "registration",
    "cdn2", "cdn3", "static1", "static2",
    "img1", "img2", "img3", "video", "videos",
    "tv", "radio", "stream", "live",
    "ebook", "library", "resources", "resource",
    "affiliate", "affiliates", "ad", "ads",
    "track", "tracker", "event", "events",
    "notify", "notification", "push", "messages",
    "soap", "xmlrpc", "json", "rest", "graphql",
    "node", "node1", "node2", "server1", "server2",
    "web1", "web2", "web3", "app1", "app2", "app3",
    "lb", "loadbalancer", "proxy", "proxy1",
    "waf", "firewall", "ids", "ips",
    "log", "syslog", "audit", "report", "reports",
    "config", "configuration", "setup", "install",
    "migration", "upgrade", "patch", "update",
    "sso", "auth", "login", "signin", "oauth",
    "iam", "identity", "user", "users", "account",
    "password", "reset", "forgot", "activate",
    "api/v1", "api/v2", "api/v3",
    "swagger", "swagger-ui", "swagger-ui.html",
    "api-docs", "apidocs", "openapi",
    "actuator", "health", "metrics", "info",
    "prometheus", "grafana", "kibana", "kibana",
    "elasticsearch", "logstash", "elk",
    "phpmyadmin", "phpPgAdmin", "phpldapadmin",
    "adminer", "adminer.php",
    "server-status", "server-info",
    "phpinfo.php", "info.php", "test.php",
    "crossdomain.xml", "clientaccesspolicy.xml",
    "robots.txt", "sitemap.xml", "sitemap",
    "humans.txt", "security.txt",
    ".well-known", ".well-known/security.txt",
    "wp-admin", "wp-content", "wp-includes",
    "wordpress", "administrator", "joomla",
    "drupal", "magento", "opencart",
    "backend", "frontend", "internal",
    "nexus", "artifactory", "harbor",
    "rancher", "portainer", "docker",
    "k8s", "kubernetes", "kube",
    "gitlab", "gitea", "gogs", "bitbucket",
    "sonarqube", "sonar", "codequality",
    "sentinel", "sentry", "errorlogging",
    "keycloak", "auth0", "okta",
    "redash", "metabase", "superset",
    "airflow", "jenkins", "teamcity",
    "argocd", "argo", "tekton",
    "vault", "consul", "nomad",
    "minio", "ceph", "s3",
    "rabbitmq", "mq", "queue",
    "kafka", "zookeeper",
    "redis", "redis1", "redis2",
    "memcached", "varnish",
    "splunk", "splunkd", "sumo",
    "datadog", "newrelic",
    "openvpn", "wireguard", "ipsec",
    "radius", "freeradius",
    "ldap", "openldap", "ad", "active-directory",
    "rdp", "remote-desktop", "citrix",
    "vmware", "vcenter", "esxi",
    "proxmox", "xenserver", "hyperv",
    "zabbix", "nagios", "icinga",
    "cacti", "observium", "librenms",
    "pfsense", "opnsense", "mikrotik",
    "ubiquiti", "unifi", "meraki",
    "ruijie", "cisco", "huawei", "h3c",
    "fortinet", "fortigate", "paloalto",
    "sonicwall", "checkpoint", "juniper",
    "office365", "sharepoint", "onedrive",
    "teams", "skype", "lync",
    "wechat", "dingtalk", "feishu",
    "zoom", "webex", "gotomeeting",
    "payment", "paypal", "alipay", "wechatpay",
    "3g", "4g", "5g", "wifi",
    "ns", "dns", "dhcp", "ntp",
    "radius", "tacacs",
    "squid", "proxy", "forward",
    "tor", "i2p",
    "deep", "darkweb", "onion",
    "research", "develop", "development",
    "production", "prod", "preprod",
    "testing", "qa", "quality",
    "training", "learn", "academy",
    "student", "teacher", "faculty",
    "library", "ebook", "course",
    "ticket", "tickets", "support",
    "feedback", "bug", "bugs",
    "changelog", "release", "releases",
    "roadmap", "status", "uptime",
    "community", "forum", "discuss",
    "wiki", "knowledgebase", "kb",
    "faq", "help", "helpcenter",
    "legal", "privacy", "terms",
    "about", "contact", "team",
    "press", "news", "events",
    "gallery", "portfolio", "showcase",
    "pricing", "plans", "subscription",
    "referral", "invite", "invitation",
    "brand", "branding", "media-kit",
    "partner", "affiliate", "reseller",
]


@dataclass
class SubdomainResult:
    domain: str
    subdomains: dict = field(default_factory=dict)  # subdomain -> ip
    total_checked: int = 0
    total_found: int = 0
    error: str = ""


class SubdomainEnumerator:
    """子域名枚举器 — 常见子域名爆破"""

    def __init__(self, domain: str, timeout: float = 3.0, concurrency: int = 50):
        self.domain = domain.lower().strip()
        if "://" in self.domain:
            self.domain = self.domain.split("://", 1)[1].split("/")[0]
        self.timeout = timeout
        self.concurrency = concurrency

    async def enumerate(self, wordlist: list[str] = None) -> SubdomainResult:
        result = SubdomainResult(domain=self.domain)
        words = wordlist or COMMON_SUBDOMAINS
        result.total_checked = len(words)

        sem = asyncio.Semaphore(self.concurrency)

        async def _check(sub: str) -> tuple[str, str] | None:
            fqdn = f"{sub}.{self.domain}"
            async with sem:
                try:
                    ips = await asyncio.wait_for(
                        asyncio.get_event_loop().getaddrinfo(fqdn, None, socket.AF_INET),
                        timeout=self.timeout
                    )
                    if ips:
                        ip = ips[0][4][0]
                        return sub, ip
                except (socket.gaierror, asyncio.TimeoutError, OSError):
                    pass
            return None

        tasks = [_check(w) for w in words]
        done = await asyncio.gather(*tasks)

        for item in done:
            if item:
                sub, ip = item
                result.subdomains[sub] = ip

        result.total_found = len(result.subdomains)
        return result

    def summary(self, result: SubdomainResult) -> dict:
        return {
            "domain": result.domain,
            "total_checked": result.total_checked,
            "total_found": result.total_found,
            "subdomains": result.subdomains,
        }
