"""
DNS 枚举模块 — A | AAAA | CNAME | MX | NS | TXT | SOA
"""

import asyncio
import socket
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class DNSResult:
    domain: str
    a_records: list = field(default_factory=list)
    aaaa_records: list = field(default_factory=list)
    cname_records: list = field(default_factory=list)
    mx_records: list = field(default_factory=list)
    ns_records: list = field(default_factory=list)
    txt_records: list = field(default_factory=list)
    soa_record: str = ""
    error: str = ""


class DNSEnumerator:
    """异步 DNS 枚举器 — 收集各种 DNS 记录"""

    def __init__(self, domain: str, timeout: float = 5.0):
        self.domain = domain.lower().strip()
        self.timeout = timeout

    async def enumerate(self) -> DNSResult:
        result = DNSResult(domain=self.domain)

        try:
            # A records
            try:
                info = await asyncio.wait_for(
                    asyncio.get_event_loop().getaddrinfo(self.domain, None, socket.AF_INET),
                    timeout=self.timeout
                )
                seen = set()
                for addr in info:
                    ip = addr[4][0]
                    if ip not in seen:
                        seen.add(ip)
                        result.a_records.append(ip)
            except Exception:
                pass

            # AAAA records
            try:
                info = await asyncio.wait_for(
                    asyncio.get_event_loop().getaddrinfo(self.domain, None, socket.AF_INET6),
                    timeout=self.timeout
                )
                seen = set()
                for addr in info:
                    ip = addr[4][0]
                    ip = ip.split('%')[0]
                    if ip not in seen:
                        seen.add(ip)
                        result.aaaa_records.append(ip)
            except Exception:
                pass

            # Try DNS resolution via system host command as fallback
            try:
                proc = await asyncio.wait_for(
                    asyncio.create_subprocess_exec(
                        "nslookup", "-type=ANY", self.domain,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    ),
                    timeout=self.timeout
                )
                stdout, _ = await asyncio.wait_for(
                    proc.communicate(), timeout=self.timeout
                )
                output = stdout.decode("latin-1", errors="replace")

                for line in output.split("\n"):
                    line = line.strip()
                    if "mail exchanger" in line.lower():
                        parts = line.split("=")
                        if len(parts) > 1:
                            result.mx_records.append(parts[1].strip())
                    elif "name server" in line.lower():
                        parts = line.split("=")
                        if len(parts) > 1:
                            result.ns_records.append(parts[1].strip())
                    elif "text = " in line.lower():
                        txt = line.split("=")[-1].strip().strip('"')
                        if txt:
                            result.txt_records.append(txt)
            except (FileNotFoundError, asyncio.TimeoutError):
                pass

        except Exception as e:
            result.error = str(e)

        return result

    def summary(self, result: DNSResult) -> dict:
        return {
            "domain": result.domain,
            "a_records": result.a_records,
            "a_count": len(result.a_records),
            "mx_records": result.mx_records,
            "ns_records": result.ns_records,
            "txt_count": len(result.txt_records),
        }
