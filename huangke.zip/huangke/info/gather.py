"""
信息收集协调器 — WHOIS | DNS | SSL | 子域名 | HTTP 头 统一入口
"""

import asyncio
import time
from dataclasses import dataclass, field
from typing import Optional

from .dns_lookup import DNSEnumerator, DNSResult
from .ssl_info import SSLInspector, SSLResult
from .subdomain_enum import SubdomainEnumerator, SubdomainResult
from .whois_lookup import WhoisLookup, WhoisResult


@dataclass
class InfoResult:
    url: str
    domain: str
    dns: Optional[DNSResult] = None
    ssl: Optional[SSLResult] = None
    subdomains: Optional[SubdomainResult] = None
    whois: Optional[WhoisResult] = None
    headers: Optional[list] = None
    elapsed: float = 0.0
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "domain": self.domain,
            "dns": {
                "a_records": self.dns.a_records if self.dns else [],
                "aaaa_records": self.dns.aaaa_records if self.dns else [],
                "mx_records": self.dns.mx_records if self.dns else [],
                "ns_records": self.dns.ns_records if self.dns else [],
                "txt_records": self.dns.txt_records[:10] if self.dns else [],
            } if self.dns else None,
            "ssl": {
                "issuer": self.ssl.issuer if self.ssl else "",
                "subject": self.ssl.subject if self.ssl else "",
                "valid_from": self.ssl.valid_from if self.ssl else "",
                "valid_to": self.ssl.valid_to if self.ssl else "",
                "days_remaining": self.ssl.days_remaining if self.ssl else 0,
                "san": self.ssl.san if self.ssl else [],
                "tls_version": self.ssl.tls_version if self.ssl else "",
                "fingerprint": self.ssl.fingerprint if self.ssl else "",
            } if self.ssl else None,
            "subdomains": {
                "total_checked": self.subdomains.total_checked if self.subdomains else 0,
                "total_found": self.subdomains.total_found if self.subdomains else 0,
                "subdomains": self.subdomains.subdomains if self.subdomains else {},
                "domain": self.subdomains.domain if self.subdomains else "",
            } if self.subdomains else None,
            "whois": self.whois.to_dict() if self.whois and not self.whois.error else None,
            "elapsed": self.elapsed,
        }

    def display(self, console):
        """在 Rich 控制台中显示信息收集结果"""
        console.print(f"  域名: [green]{self.domain}[/green]")

        if self.dns:
            if self.dns.a_records:
                console.print(f"  A 记录: [cyan]{', '.join(self.dns.a_records)}[/cyan]")
            if self.dns.aaaa_records:
                console.print(f"  AAAA 记录: [cyan]{', '.join(self.dns.aaaa_records)}[/cyan]")
            if self.dns.mx_records:
                console.print(f"  MX 记录: [yellow]{', '.join(self.dns.mx_records)}[/yellow]")
            if self.dns.ns_records:
                console.print(f"  NS 记录: [yellow]{', '.join(self.dns.ns_records)}[/yellow]")
            if self.dns.txt_records:
                console.print(f"  TXT 记录: [dim]{', '.join(self.dns.txt_records[:3])}[/dim]")

        if self.ssl:
            if self.ssl.issuer:
                console.print(f"  SSL 颁发者: [green]{self.ssl.issuer[:80]}[/green]")
            if self.ssl.tls_version:
                console.print(f"  TLS 版本: [cyan]{self.ssl.tls_version}[/cyan]")
            if self.ssl.days_remaining:
                color = "green" if self.ssl.days_remaining > 30 else ("yellow" if self.ssl.days_remaining > 7 else "red")
                console.print(f"  证书剩余: [{color}]{self.ssl.days_remaining} 天[/{color}]")
            if self.ssl.san:
                console.print(f"  SAN: [dim]{len(self.ssl.san)} 个域名[/dim]")
            if self.ssl.fingerprint:
                console.print(f"  指纹: [dim]{self.ssl.fingerprint[:40]}...[/dim]")
            if self.ssl.error:
                console.print(f"  SSL 错误: [red]{self.ssl.error}[/red]")

        if self.subdomains:
            found = self.subdomains.total_found
            checked = self.subdomains.total_checked
            console.print(f"  子域名: [cyan]{found}[/cyan]/{checked} 个解析成功")
            for sub, ip in list(self.subdomains.subdomains.items())[:10]:
                console.print(f"    [green]{sub}.{self.domain}[/green] → [dim]{ip}[/dim]")

        if self.whois and not self.whois.error:
            if self.whois.registrar:
                console.print(f"  注册商: [cyan]{self.whois.registrar}[/cyan]")
            if self.whois.creation_date:
                console.print(f"  创建时间: [dim]{self.whois.creation_date}[/dim]")
            if self.whois.expiration_date:
                console.print(f"  到期时间: [dim]{self.whois.expiration_date}[/dim]")
            if self.whois.org:
                console.print(f"  组织: [dim]{self.whois.org}[/dim]")
            if self.whois.country:
                console.print(f"  国家: [dim]{self.whois.country}[/dim]")

        console.print(f"  耗时: [cyan]{self.elapsed:.1f}s[/cyan]")


class InfoGatherer:
    """信息收集协调器 - 并行执行所有信息收集任务"""

    def __init__(self, url: str, timeout: float = 10.0, proxy: str = None):
        self.url = url
        domain = url.lower().strip()
        if "://" in domain:
            domain = domain.split("://", 1)[1].split("/")[0].split(":")[0]
        self.domain = domain
        self.timeout = timeout
        self.proxy = proxy

    async def gather_all(self) -> InfoResult:
        result = InfoResult(url=self.url, domain=self.domain)
        start = time.time()

        tasks = {}

        # DNS enumeration
        try:
            dns_enum = DNSEnumerator(self.domain, timeout=self.timeout)
            tasks["dns"] = asyncio.ensure_future(dns_enum.enumerate())
        except Exception:
            pass

        # SSL inspection
        try:
            ssl_inspector = SSLInspector(self.domain, timeout=self.timeout)
            tasks["ssl"] = asyncio.ensure_future(ssl_inspector.inspect())
        except Exception:
            pass

        # Subdomain enumeration
        try:
            sub_enum = SubdomainEnumerator(self.domain, timeout=min(self.timeout * 0.3, 3.0), concurrency=50)
            tasks["sub"] = asyncio.ensure_future(sub_enum.enumerate())
        except Exception:
            pass

        # WHOIS lookup
        try:
            whois_lookup = WhoisLookup(timeout=self.timeout)
            tasks["whois"] = asyncio.ensure_future(whois_lookup.lookup(self.domain))
        except Exception:
            pass

        # Wait for all tasks
        if tasks:
            done = await asyncio.gather(*tasks.values(), return_exceptions=True)
            for key, task_result in zip(tasks.keys(), done):
                if isinstance(task_result, Exception):
                    continue
                if key == "dns":
                    result.dns = task_result
                elif key == "ssl":
                    result.ssl = task_result
                elif key == "sub":
                    result.subdomains = task_result
                elif key == "whois":
                    result.whois = task_result

        result.elapsed = time.time() - start
        return result
