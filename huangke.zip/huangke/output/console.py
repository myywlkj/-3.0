"""Rich 控制台输出 — 中文界面 | 进度条 | 彩色表格"""

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, BarColumn, TextColumn, TimeElapsedColumn
from rich.text import Text
from rich import box

from ..core.scanner import ScanResult
from ..core.fingerprint import ServerInfo
from ..core.analyzer import ContentFinding
from ..core.port_scanner import PortResult
from ..utils.risk import Severity as _Severity

console = Console()

# ═══════════════════════════════════════════════════════
# 艺术标题
# ═══════════════════════════════════════════════════════

BANNER = r"""[bold bright_red]
                            ██╗  ██╗██╗   ██╗ █████╗ ███╗   ██╗ ██████╗
                            ██║  ██║██║   ██║██╔══██╗████╗  ██║██╔════╝
                            ███████║██║   ██║███████║██╔██╗ ██║██║  ███╗
                            ██╔══██║██║   ██║██╔══██║██║╚██╗██║██║   ██║
                            ██║  ██║╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝
                            ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝[/bold bright_red]
[bold cyan]                       ═══════════════════════════════════════════════════
                                黄客联盟 · 红队渗透测试工具套件  v3.0
				开发者  糯沫   QQ群 1077929938
                       目录扫描 | 指纹识别 | 端口扫描 | 内容分析 | 信息收集
                       ═══════════════════════════════════════════════════[/bold cyan]
"""

BANNER_COMPACT = "  [bold bright_red]黄客联盟[/bold bright_red] [bold cyan]v3.0[/bold cyan]  [dim]红队渗透测试工具套件[/dim]"


def print_banner():
    console.print(BANNER)


def print_banner_compact():
    console.print(BANNER_COMPACT)


def print_menu():
    console.print(BANNER)
    console.print()
    console.print("  [bold white]╔════════════════════════════════════════════╗[/bold white]")
    console.print("  [bold white]║[/bold white]  [bold cyan]命令                      说明[/bold cyan]            [bold white]║[/bold white]")
    console.print("  [bold white]╠════════════════════════════════════════════╣[/bold white]")
    console.print("  [bold white]║[/bold white]  [bold green]1.[/bold green] 完整扫描    目录+端口+指纹+内容分析    [bold white]║[/bold white]")
    console.print("  [bold white]║[/bold white]  [bold green]2.[/bold green] 目录扫描    暴力破解目录和文件路径     [bold white]║[/bold white]")
    console.print("  [bold white]║[/bold white]  [bold green]3.[/bold green] 端口扫描    TCP端口+服务识别           [bold white]║[/bold white]")
    console.print("  [bold white]║[/bold white]  [bold green]4.[/bold green] 指纹识别    识别Web技术栈/中间件       [bold white]║[/bold white]")
    console.print("  [bold white]║[/bold white]  [bold green]5.[/bold green] 批量扫描    从文件批量扫描多个目标     [bold white]║[/bold white]")
    console.print("  [bold white]║[/bold white]  [bold green]6.[/bold green] Web面板    启动 Web 可视化控制台       [bold white]║[/bold white]")
    console.print("  [bold white]║[/bold white]  [bold green]7.[/bold green] 使用说明    参数详解和示例             [bold white]║[/bold white]")
    console.print("  [bold white]║[/bold white]  [bold green]8.[/bold green] 关于工具    版本和开发者信息           [bold white]║[/bold white]")
    console.print("  [bold white]║[/bold white]  [bold green]9.[/bold green] 信息收集    WHOIS/DNS/SSL/子域名分析   [bold white]║[/bold white]")
    console.print("  [bold white]║[/bold white]  [bold red]0.[/bold red] 退出                                   [bold white]║[/bold white]")
    console.print("  [bold white]╚════════════════════════════════════════════╝[/bold white]")
    console.print()
    console.print("  [dim]请输入对应数字并按回车...[/dim]")


def print_about():
    about = """[bold cyan]
          ╔══════════════════════════════════════════╗
          ║                                          ║
          ║   [/bold cyan][bold bright_red]黄客联盟 · 渗透测试工具箱[/bold bright_red]              [bold cyan]║
          ║   [/bold cyan][dim]HuangKe Alliance Toolkit[/dim]               [bold cyan]║
          ║                                          ║
          ║   [/bold cyan]版本       : [green]v3.0[/green]                      [bold cyan]║
          ║   [/bold cyan]Python     : [green]3.10+[/green]                     [bold cyan]║
          ║   [/bold cyan]开发者     : [green]黄客联盟创始人  糯沫 [/green]     [bold cyan]║
          ║   [/bold cyan]平台       : [green]跨平台[/green]                    [bold cyan]║
          ║                                          ║
          ║   [/bold cyan]功能                                   [bold cyan]║
          ║   [/bold cyan][dim]目录暴力破解  |  技术栈指纹识别[/dim]        [bold cyan]║
          ║   [/bold cyan][dim]TCP端口扫描   |  页面内容分析[/dim]          [bold cyan]║
          ║   [/bold cyan][dim]WAF/防火墙检测 |  安全响应头检查[/dim]       [bold cyan]║
          ║   [/bold cyan][dim]CDN识别       |  批量目标扫描[/dim]          [bold cyan]║
          ║   [/bold cyan][dim]WHOIS/DNS查询 |  SSL证书/子域名分析[/dim]    [bold cyan]║
          ║   [/bold cyan][dim]JSON/HTML/CSV/MD导出  |  异步高并发[/dim]    [bold cyan]║
          ║                                          ║
          ║   [/bold cyan][bold red]仅供授权安全测试使用！[/bold red]                 [bold cyan]║
          ║                                          ║
          ╚══════════════════════════════════════════╝[/bold cyan]
"""
    console.print(about)


def create_progress():
    return Progress(
        TextColumn("  [bold cyan]{task.description}[/bold cyan]"),
        BarColumn(bar_width=40, style="bright_black", complete_style="bright_red"),
        TextColumn("[bold yellow]{task.completed}[/bold yellow]/[dim]{task.total}[/dim]"),
        TimeElapsedColumn(),
        console=console,
        transient=False,
    )


# ═══════════════════════════════════════════════
# 端口扫描结果
# ═══════════════════════════════════════════════

def print_port_results(results: list, host: str):
    if not results:
        console.print("\n  [yellow]未发现开放端口[/yellow]")
        return

    open_count = len(results)
    critical = sum(1 for r in results if r.severity.label == "严重")
    high = sum(1 for r in results if r.severity.label == "高危")

    table = Table(
        title=f"\n  [bold cyan]TCP 端口扫描结果[/bold cyan] — [green]{host}[/green]",
        box=box.ROUNDED, header_style="bold white", border_style="dim",
        title_justify="left",
    )
    table.add_column("#", justify="right", style="dim", width=4)
    table.add_column("端口", justify="right", style="cyan", width=6)
    table.add_column("服务", style="bold", width=14)
    table.add_column("状态", justify="center", width=6)
    table.add_column("指纹", style="dim", max_width=30)
    table.add_column("风险", justify="center", width=8)
    table.add_column("说明", style="dim", max_width=42)

    for i, r in enumerate(sorted(results, key=lambda x: (x.severity.score, x.port), reverse=True), 1):
        sev_color = r.severity.color
        table.add_row(
            str(i), str(r.port), r.service,
            f"[green]{r.state}[/green]",
            r.banner[:28] if r.banner else "—",
            f"[{sev_color}]{r.severity.label}[/{sev_color}]",
            r.risk_desc[:40],
        )

    console.print()
    console.print(table)
    console.print()
    _print_port_breakdown(results)


def _print_port_breakdown(results: list):
    sev_counts = {}
    for r in results:
        sev_counts[r.severity.label] = sev_counts.get(r.severity.label, 0) + 1
    parts = []
    for label in ["严重", "高危", "中危", "低危", "信息"]:
        count = sev_counts.get(label, 0)
        if count > 0:
            sev = next(s for s in _Severity if s.label == label)
            parts.append(f"[{sev.color}]{label}: {count}[/{sev.color}]")
    if parts:
        console.print("  " + "  ·  ".join(parts))


# ═══════════════════════════════════════════════
# 目录扫描结果
# ═══════════════════════════════════════════════

def print_scan_results(results: list, base_url: str, verbose: bool = False):
    if not results:
        console.print("\n  [yellow]未发现任何端点或目录[/yellow]")
        return

    stats = _compute_stats(results)
    console.print()

    from rich.text import Text as RichText
    summary = RichText.from_markup(
        "  [bold cyan]扫描统计[/bold cyan]  "
        f"总计: [bold]{stats['total']}[/bold]  "
        f"[green]2xx: {stats['200']}[/green]  "
        f"[yellow]3xx: {stats['30x']}[/yellow]  "
        f"[red]4xx: {stats['403'] + stats['401']}[/red]  "
        f"[dark_orange]5xx: {stats['500']}[/dark_orange]  "
        f"[dim]404: {stats['404']}[/dim]"
    )
    console.print(summary)

    table = Table(
        title=f"\n  [bold cyan]发现的端点[/bold cyan] — [green]{base_url}[/green]",
        box=box.ROUNDED, header_style="bold white", border_style="dim",
        title_justify="left",
    )
    table.add_column("路径", style="cyan", no_wrap=True, max_width=40)
    table.add_column("状态码", justify="center", width=6)
    table.add_column("风险", justify="center", width=8)
    table.add_column("服务", style="bright_blue", max_width=18)
    table.add_column("大小", justify="right", width=7)
    table.add_column("说明", style="dim", max_width=48)

    severity_order = {"严重": 0, "高危": 1, "中危": 2, "低危": 3, "信息": 4}
    sorted_results = sorted(
        results, key=lambda r: (severity_order.get(r.severity.label, 99), r.path)
    )

    for r in sorted_results:
        sev_color = r.severity.color
        service_name = r.service[:16] if hasattr(r, 'service') and r.service else ""
        table.add_row(
            r.path,
            _status_color(r.status),
            f"[{sev_color}]{r.severity.label}[/{sev_color}]",
            f"[dim]{service_name}[/dim]" if service_name else "",
            _format_size(r.content_length),
            r.risk_desc[:46],
        )
        if verbose and r.body_preview and r.status == 200:
            preview = r.body_preview[:120].replace("\n", " ").strip()
            if preview:
                table.add_row("", "", f"[dim]预览:[/dim] [bright_black]{preview}[/bright_black]", "", "", "")

    console.print(table)
    console.print()
    _print_severity_breakdown(results)

    interesting = [r for r in sorted_results if r.severity.score >= 3 and r.body_preview]
    if interesting and not verbose:
        console.print(f"\n  [dim]{len(interesting)} 个中危及以上端点有响应内容，使用 [bold]--verbose[/bold] 查看预览[/dim]")


# ═══════════════════════════════════════════════
# 指纹识别结果
# ═══════════════════════════════════════════════

def print_fingerprint(info: ServerInfo):
    if not info.technologies and not info.waf and not info.page_title:
        console.print("\n  [yellow]未识别到任何技术栈特征[/yellow]")
        return

    console.print()
    console.print(Panel("[bold cyan]网站指纹分析[/bold cyan]", border_style="cyan"))

    if info.page_title:
        console.print(f"  网站标题: [bold green]{info.page_title}[/bold green]")
    if info.server:
        console.print(f"  服务器:   [cyan]{info.server}[/cyan]")
    if info.powered_by:
        console.print(f"  运行环境: [cyan]{info.powered_by}[/cyan]")
    if info.generator:
        console.print(f"  内容管理: [cyan]{info.generator}[/cyan]")
    if info.ip:
        console.print(f"  IP 地址:  [dim]{info.ip}[/dim]")

    if info.technologies:
        console.print()
        tech_table = Table(title="  [bold]识别到的技术栈[/bold]", box=box.SIMPLE, border_style="dim",
                           title_justify="left")
        tech_table.add_column("分类", style="dim", width=14)
        tech_table.add_column("名称", style="cyan bold")
        tech_table.add_column("置信度", justify="center", width=10)
        tech_table.add_column("证据", style="dim", max_width=50)

        for t in info.technologies:
            conf_map = {"high": ("高", "green"), "medium": ("中", "yellow"), "low": ("低", "dim")}
            cn, color = conf_map.get(t.confidence, ("低", "dim"))
            tech_table.add_row(t.category, t.name, f"[{color}]{cn}[/{color}]", t.evidence[:48])
        console.print(tech_table)

    if info.cdn:
        console.print()
        cdn_table = Table(title="  [bold magenta]CDN / 加速节点[/bold magenta]", box=box.SIMPLE, border_style="magenta",
                          title_justify="left")
        cdn_table.add_column("提供商", style="magenta bold")
        cdn_table.add_column("证据", style="dim", max_width=58)
        for c in info.cdn:
            cdn_table.add_row(c.name, c.evidence)
        console.print(cdn_table)

    if info.waf:
        console.print()
        waf_table = Table(title="  [bold red]WAF / 安全防护检测[/bold red]", box=box.SIMPLE, border_style="red",
                          title_justify="left")
        waf_table.add_column("名称", style="red bold")
        waf_table.add_column("证据", style="dim", max_width=58)
        for w in info.waf:
            waf_table.add_row(w.name, w.evidence)
        console.print(waf_table)

    if info.security_headers:
        console.print()
        present = sum(1 for v in info.security_headers.values() if v != "MISSING")
        total = len(info.security_headers)
        sec_table = Table(
            title=f"  [bold]安全响应头[/bold] ([green]{present}[/green]/[dim]{total}[/dim] 已设置)",
            box=box.SIMPLE, border_style="dim", title_justify="left",
        )
        sec_table.add_column("响应头", style="dim", width=30)
        sec_table.add_column("状态", max_width=58)
        for header, value in info.security_headers.items():
            if value == "MISSING":
                sec_table.add_row(header, "[red]缺失[/red]")
            else:
                sec_table.add_row(header, f"[green]{value[:55]}[/green]")
        console.print(sec_table)
        if total - present > 0:
            console.print(f"\n  [yellow]{total - present} 项安全响应头未设置[/yellow]")


# ═══════════════════════════════════════════════
# 内容分析结果
# ═══════════════════════════════════════════════

def print_analysis(findings: list):
    if not findings:
        console.print("\n  [yellow]内容分析未发现风险项[/yellow]")
        return

    console.print()
    console.print(Panel("[bold yellow]页面内容分析[/bold yellow]", border_style="yellow"))

    table = Table(box=box.SIMPLE, border_style="dim")
    table.add_column("风险", justify="center", width=8)
    table.add_column("类型", style="cyan", width=24)
    table.add_column("详情", style="dim", max_width=52)
    table.add_column("位置", style="dim", max_width=40)

    for f in findings:
        sev_color = f.severity.color
        table.add_row(
            f"[{sev_color}]{f.severity.label}[/{sev_color}]",
            f.finding_type,
            f.detail[:50],
            f.url[:38],
        )
    console.print(table)


# ═══════════════════════════════════════════════
# 扫描总览
# ═══════════════════════════════════════════════

def print_summary(scan_results, fingerprint_info, content_findings, elapsed: float):
    from rich.text import Text as RichText
    lines = []
    lines.append(f"  扫描完成，耗时 [bold cyan]{elapsed:.2f} 秒[/bold cyan]\n")

    if scan_results:
        sev_counts = {}
        for r in scan_results:
            sev_counts[r.severity.label] = sev_counts.get(r.severity.label, 0) + 1
        lines.append(f"  [bold]发现端点:[/bold] [green]{len(scan_results)}[/green] 个\n")
        for label in ["严重", "高危", "中危", "低危", "信息"]:
            count = sev_counts.get(label, 0)
            if count:
                sev = next(s for s in _Severity if s.label == label)
                lines.append(f"    [{sev.color}]• {label}: {count}[/{sev.color}]\n")

    if fingerprint_info:
        if fingerprint_info.page_title:
            lines.append(f"\n  [bold]网站标题:[/bold] {fingerprint_info.page_title}\n")
        if fingerprint_info.technologies:
            lines.append(f"  [bold]识别技术:[/bold] [cyan]{len(fingerprint_info.technologies)}[/cyan] 项\n")
        if fingerprint_info.waf:
            lines.append(f"  [bold]WAF 检测:[/bold] [red]{len(fingerprint_info.waf)}[/red] 个\n")
        if fingerprint_info.cdn:
            lines.append(f"  [bold]CDN 检测:[/bold] [magenta]{len(fingerprint_info.cdn)}[/magenta] 个\n")

    if content_findings:
        lines.append(f"\n  [bold]内容风险:[/bold] [yellow]{len(content_findings)}[/yellow] 项\n")

    panel_content = RichText.from_markup("".join(lines))
    console.print(Panel(panel_content, title="[bold green]扫描总览[/bold green]", border_style="green"))


# ═══════════════════════════════════════════════
# 使用说明
# ═══════════════════════════════════════════════

def print_usage_guide():
    guide = """
[bold cyan]黄客联盟 · 渗透测试工具箱 — 使用说明[/bold cyan]
[dim]══════════════════════════════════════════════════════════════[/dim]

[bold]可用命令[/bold]
  [green]full[/green]     完整扫描 — 目录 + 端口 + 指纹 + 内容分析，四合一
  [green]scan[/green]     目录扫描 — 暴力破解隐藏目录、文件、接口
  [green]port[/green]     端口扫描 — TCP 端口开放检测 + 服务识别 + 风险评估
  [green]finger[/green]   指纹识别 — Web 技术栈、CMS、WAF、CDN 识别
  [green]batch[/green]    批量扫描 — 从文件读取多个目标地址，逐一遍历
  [green]info[/green]     信息收集 — WHOIS / DNS / SSL / 子域名分析
  [green]web[/green]      Web 面板 — 启动可视化 Web 控制台，浏览器操作

[bold]常用参数[/bold]
  [cyan]-u, --url[/cyan]       目标 URL (必填)
  [cyan]-w, --wordlist[/cyan]  词表选择: [dim]default / common / sensitive / api[/dim] 或自定义路径
  [cyan]-t, --threads[/cyan]   并发线程数 (默认: [dim]30[/dim])
  [cyan]-d, --delay[/cyan]     请求间隔秒数 (防封 IP，建议 0.1~0.5)
  [cyan]-r, --recursive[/cyan] 递归扫描发现的目录
  [cyan]-o, --output[/cyan]    输出报告: [dim]report.html / result.json / scan.csv / scan.md[/dim]
  [cyan]-p, --proxy[/cyan]     代理地址: [dim]http://127.0.0.1:8080[/dim] 或 [dim]socks5://localhost:1080[/dim]
  [cyan]-k, --no-verify[/cyan] 跳过 SSL 证书验证
  [cyan]-v, --verbose[/cyan]   显示响应内容预览
  [cyan]--timeout[/cyan]       请求超时秒数 (默认: [dim]10[/dim])
  [cyan]-j, --jobs[/cyan]      批量扫描并行进程数 (默认: [dim]自动[/dim])
  [cyan]--json[/cyan]          JSON 输出模式 — 静默执行，结构化结果到 stdout
  [cyan]--webhook[/cyan]       URL — 扫描完成回调，HTTP POST JSON 结果
  [cyan]--ci[/cyan]            CI 模式 — 高危以上发现返回非零退出码
  [cyan]--config[/cyan]        从 JSON/YAML 配置文件加载自动化扫描

[bold]使用示例[/bold]
  [dim]# 完整扫描 + 导出 HTML 报告[/dim]
  python -m huangke full -u https://target.com -o report.html

  [dim]# 目录扫描，仅扫描敏感文件，加延迟[/dim]
  python -m huangke scan -u https://target.com -w sensitive -d 0.5

  [dim]# 递归扫描 + 自定义并发和超时[/dim]
  python -m huangke full -u https://target.com -r -t 20 --timeout 15

  [dim]# 通过 SOCKS5 代理扫描[/dim]
  python -m huangke full -u https://target.com -p socks5://127.0.0.1:1080

  [dim]# 端口扫描 (域名或IP均可)[/dim]
  python -m huangke port -u target.com

  [dim]# 指纹识别 + 跳过 SSL 验证[/dim]
  python -m huangke finger -u https://target.com -k

  [dim]# 使用自定义词表文件[/dim]
  python -m huangke scan -u https://target.com -w /path/to/words.txt

  [dim]# 扫描后导出多种格式[/dim]
  python -m huangke full -u https://target.com -o result.json
  python -m huangke full -u https://target.com -o report.html
  python -m huangke full -u https://target.com -o scan.csv
  python -m huangke full -u https://target.com -o scan.md

  [dim]# 批量扫描 (目标列表文件每行一个URL)[/dim]
  python -m huangke batch -f targets.txt -w common -o batch_report.html

  [dim]# 启动 Web 控制面板[/dim]
  python -m huangke web
  python -m huangke web --host 0.0.0.0 --port 9000
  python -m huangke web --no-browser

  [dim]# 信息收集 (WHOIS+DNS+SSL+子域名)[/dim]
  python -m huangke info -u https://target.com
  python -m huangke info -u target.com --timeout 15

[bold]自动化模式[/bold]
  [dim]# JSON 输出 — 静默扫描，结果写 stdout，可管道到 jq[/dim]
  python -m huangke full -u https://target.com --json | jq .summary

  [dim]# CI 模式 — 高危以上发现时返回非零退出码 (exit 1)[/dim]
  python -m huangke full -u https://target.com --ci

  [dim]# Webhook 回调 — 扫描完成自动 POST JSON 到指定 URL[/dim]
  python -m huangke full -u https://target.com --webhook https://api.example.com/hook

  [dim]# 配置文件 — 定义多个目标和扫描类型，一键执行[/dim]
  python -m huangke --config scan-config.json

  [dim]# 批量 + 多进程 — 同时扫描多个目标[/dim]
  python -m huangke batch -f targets.txt -j 4

[bold]风险等级说明[/bold]
  [red]严重[/red]  Git/SVN 泄露、私钥、数据库密码、.env 文件、硬编码凭据
  [dark_orange]高危[/dark_orange]  配置文件暴露、后台管理页面、目录浏览、备份文件、证书泄露
  [yellow]中危[/yellow]  调试端点、API 接口、版本号泄露、非生产环境
  [blue]低危[/blue]  HTML 注释、邮箱暴露、隐藏表单字段
  [dim]信息[/dim]  普通响应、跳转、公开信息

[bold red]仅供授权安全测试使用！未经授权扫描他人系统属违法行为。[/bold red]
"""
    console.print(guide)


# ═══════════════════════════════════════════════
# 内部辅助
# ═══════════════════════════════════════════════

def _compute_stats(results: list) -> dict:
    stats = {"total": len(results), "200": 0, "30x": 0, "401": 0, "403": 0, "404": 0, "500": 0}
    for r in results:
        if r.status == 200:
            stats["200"] += 1
        elif r.status in (301, 302, 307, 308):
            stats["30x"] += 1
        elif r.status == 401:
            stats["401"] += 1
        elif r.status == 403:
            stats["403"] += 1
        elif r.status == 404:
            stats["404"] += 1
        elif r.status >= 500:
            stats["500"] += 1
    return stats


def _print_severity_breakdown(results: list):
    sev_counts = {}
    for r in results:
        sev_counts[r.severity.label] = sev_counts.get(r.severity.label, 0) + 1
    parts = []
    for label in ["严重", "高危", "中危", "低危", "信息"]:
        count = sev_counts.get(label, 0)
        if count > 0:
            sev = next(s for s in _Severity if s.label == label)
            parts.append(f"[{sev.color}]{label}: {count}[/{sev.color}]")
    if parts:
        console.print("  " + "  ·  ".join(parts))


def _status_color(status: int) -> str:
    if 200 <= status < 300:
        return f"[green]{status}[/green]"
    if 300 <= status < 400:
        return f"[yellow]{status}[/yellow]"
    if status in (401, 403):
        return f"[dark_orange]{status}[/dark_orange]"
    if status >= 500:
        return f"[red]{status}[/red]"
    return f"[dim]{status}[/dim]"


def _format_size(size: int) -> str:
    if size == 0:
        return "—"
    if size < 1024:
        return f"{size}B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f}K"
    return f"{size / (1024 * 1024):.1f}M"
