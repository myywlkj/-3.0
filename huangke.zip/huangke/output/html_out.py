"""HTML report output formatter."""

from datetime import datetime

from ..core.scanner import ScanResult
from ..core.fingerprint import ServerInfo
from ..core.analyzer import ContentFinding

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Aurox Toolkit 报告 — {target}</title>
<style>
:root {{ --bg: #0d1117; --fg: #c9d1d9; --border: #30363d; --accent: #58a6ff;
  --crit: #f85149; --high: #d29922; --med: #d2a843; --low: #58a6ff; --info: #8b949e; }}
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  background: var(--bg); color: var(--fg); line-height: 1.5; padding: 24px; max-width: 1200px; margin: 0 auto; }}
h1 {{ font-size: 1.6em; margin-bottom: 4px; }}
h2 {{ font-size: 1.2em; margin: 24px 0 12px; border-bottom: 1px solid var(--border); padding-bottom: 6px; }}
table {{ width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 0.9em; }}
th, td {{ padding: 8px 12px; text-align: left; border-bottom: 1px solid var(--border); }}
th {{ color: #8b949e; font-weight: 600; text-transform: uppercase; font-size: 0.78em; letter-spacing: 0.5px; }}
tr:hover {{ background: #161b22; }}
.meta {{ color: #8b949e; font-size: 0.85em; margin-bottom: 20px; }}
.badge {{ display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 0.78em; font-weight: 600; text-transform: uppercase; }}
.badge-critical {{ background: #f8514922; color: var(--crit); border: 1px solid #f8514944; }}
.badge-high {{ background: #d2992222; color: var(--high); border: 1px solid #d2992244; }}
.badge-medium {{ background: #d2a84322; color: var(--med); border: 1px solid #d2a84344; }}
.badge-low {{ background: #58a6ff22; color: var(--low); border: 1px solid #58a6ff44; }}
.badge-info {{ background: #8b949e22; color: var(--info); border: 1px solid #8b949e44; }}
.path {{ font-family: 'Consolas', 'Courier New', monospace; color: var(--accent); word-break: break-all; }}
.detail {{ color: #8b949e; font-size: 0.88em; }}
.collapsible {{ cursor: pointer; }}
.collapsible:hover {{ color: var(--accent); }}
.content-collapse {{ display: none; margin-top: 8px; }}
.content-collapse.open {{ display: block; }}
pre {{ background: #161b22; padding: 12px; border-radius: 6px; overflow-x: auto; font-size: 0.82em; border: 1px solid var(--border); }}
.summary-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; margin: 16px 0; }}
.summary-card {{ background: #161b22; border: 1px solid var(--border); border-radius: 8px; padding: 16px; text-align: center; }}
.summary-card .count {{ font-size: 2em; font-weight: 700; }}
.summary-card .label {{ color: #8b949e; font-size: 0.82em; margin-top: 4px; }}
.missing {{ color: var(--crit); }}
footer {{ margin-top: 40px; padding-top: 16px; border-top: 1px solid var(--border); color: #484f58; font-size: 0.8em; text-align: center; }}
</style>
</head>
<body>
<h1>Aurox Toolkit 扫描报告</h1>
<div class="meta">
  目标: <strong>{target}</strong> &bull;
  扫描时间: {timestamp} &bull;
  耗时: {elapsed:.1f}s
</div>

{summary_section}
{scan_section}
{fingerprint_section}
{analysis_section}

<footer>Aurox Toolkit v1.0 &mdash; 仅限授权安全测试使用</footer>

<script>
document.querySelectorAll('.collapsible').forEach(el => {{
  el.addEventListener('click', () => {{
    el.nextElementSibling.classList.toggle('open');
  }});
}});
</script>
</body>
</html>"""


SEV_LABEL_TO_CLASS = {"严重": "critical", "高危": "high", "中危": "medium", "低危": "low", "信息": "info"}


def render_html(scan_results: list[ScanResult],
                fingerprint_info: ServerInfo | None,
                content_findings: list[ContentFinding],
                target_url: str,
                elapsed: float) -> str:
    """Generate a self-contained HTML report."""

    # Summary section
    sev_counts = {}
    for r in scan_results:
        sev_counts[r.severity.label] = sev_counts.get(r.severity.label, 0) + 1

    content_sev_counts = {}
    for f in content_findings:
        content_sev_counts[f.severity.label] = content_sev_counts.get(f.severity.label, 0) + 1

    summary = '<h2>扫描总览</h2>\n<div class="summary-grid">\n'
    for label in ["严重", "高危", "中危", "低危", "信息"]:
        scan_count = sev_counts.get(label, 0)
        content_count = content_sev_counts.get(label, 0)
        total = scan_count + content_count
        if total > 0:
            css_class = SEV_LABEL_TO_CLASS.get(label, "info")
            color_var = {"严重": "crit", "高危": "high", "中危": "med", "低危": "low", "信息": "info"}[label]
            summary += f'<div class="summary-card"><div class="count" style="color:var(--{color_var})">{total}</div><div class="label">{label}</div></div>\n'
    summary += '</div>\n'

    # Scan results section
    scan_html = "<h2>发现的端点</h2>\n"
    if scan_results:
        scan_html += "<table><thead><tr><th>路径</th><th>状态码</th><th>类型</th><th>大小</th><th>风险等级</th></tr></thead><tbody>\n"
        for r in sorted(scan_results, key=lambda x: x.severity.score, reverse=True):
            css_class = SEV_LABEL_TO_CLASS.get(r.severity.label, "info")
            scan_html += (
                f'<tr><td class="path">{_escape(r.path)}</td>'
                f'<td>{r.status}</td>'
                f'<td class="detail">{_escape(r.content_type[:40]) if r.content_type else "—"}</td>'
                f'<td>{_format_size_html(r.content_length)}</td>'
                f'<td><span class="badge badge-{css_class}">{r.severity.label}</span></td></tr>\n'
            )
            if r.risk_desc:
                scan_html += f'<tr><td colspan="5" class="detail" style="padding-left:24px">{_escape(r.risk_desc)}</td></tr>\n'
        scan_html += "</tbody></table>\n"
    else:
        scan_html += "<p class='detail'>未发现任何端点或目录。</p>\n"

    # Fingerprint section
    fp_html = "<h2>网站指纹分析</h2>\n"
    if fingerprint_info and (fingerprint_info.technologies or fingerprint_info.waf):
        if fingerprint_info.server:
            fp_html += f"<p><strong>服务器:</strong> {_escape(fingerprint_info.server)}</p>\n"
        if fingerprint_info.powered_by:
            fp_html += f"<p><strong>运行环境:</strong> {_escape(fingerprint_info.powered_by)}</p>\n"
        if fingerprint_info.generator:
            fp_html += f"<p><strong>生成器/CMS:</strong> {_escape(fingerprint_info.generator)}</p>\n"

        if fingerprint_info.technologies:
            fp_html += "<table><thead><tr><th>分类</th><th>名称</th><th>置信度</th><th>证据</th></tr></thead><tbody>\n"
            for t in fingerprint_info.technologies:
                conf_cn = {"high": "高", "medium": "中", "low": "低"}.get(t.confidence, "低")
                fp_html += (
                    f'<tr><td class="detail">{_escape(t.category)}</td>'
                    f'<td><strong>{_escape(t.name)}</strong></td>'
                    f'<td>{conf_cn}</td>'
                    f'<td class="detail">{_escape(t.evidence[:60])}</td></tr>\n'
                )
            fp_html += "</tbody></table>\n"

        if getattr(fingerprint_info, "cdn", []):
            fp_html += "<h3>CDN / Edge 检测</h3><table><thead><tr><th>名称</th><th>证据</th></tr></thead><tbody>\n"
            for c in fingerprint_info.cdn:
                fp_html += f'<tr><td><span class="badge badge-medium">{_escape(c.name)}</span></td><td class="detail">{_escape(c.evidence)}</td></tr>\n'
            fp_html += "</tbody></table>\n"

        if fingerprint_info.waf:
            fp_html += "<h3>WAF / 安全防护检测</h3><table><thead><tr><th>名称</th><th>证据</th></tr></thead><tbody>\n"
            for w in fingerprint_info.waf:
                fp_html += f'<tr><td><span class="badge badge-high">{_escape(w.name)}</span></td><td class="detail">{_escape(w.evidence)}</td></tr>\n'
            fp_html += "</tbody></table>\n"

        if fingerprint_info.security_headers:
            fp_html += "<h3>安全响应头检测</h3><table><thead><tr><th>安全头</th><th>状态</th></tr></thead><tbody>\n"
            for h, v in fingerprint_info.security_headers.items():
                if v == "MISSING":
                    fp_html += f'<tr><td>{_escape(h)}</td><td class="missing">缺失</td></tr>\n'
                else:
                    fp_html += f'<tr><td>{_escape(h)}</td><td class="detail" style="color:#3fb950">{_escape(v[:80])}</td></tr>\n'
            fp_html += "</tbody></table>\n"
    else:
        fp_html += "<p class='detail'>未识别到任何技术栈特征。</p>\n"

    # Content analysis section
    analysis_html = "<h2>页面内容分析</h2>\n"
    if content_findings:
        analysis_html += "<table><thead><tr><th>等级</th><th>类型</th><th>详情</th><th>URL</th></tr></thead><tbody>\n"
        for f in content_findings:
            css_class = SEV_LABEL_TO_CLASS.get(f.severity.label, "info")
            analysis_html += (
                f'<tr><td><span class="badge badge-{css_class}">{f.severity.label}</span></td>'
                f'<td>{_escape(f.finding_type)}</td>'
                f'<td class="detail">{_escape(f.detail[:80])}</td>'
                f'<td class="path" style="font-size:0.85em">{_escape(f.url[:50])}</td></tr>\n'
            )
        analysis_html += "</tbody></table>\n"
    else:
        analysis_html += "<p class='detail'>内容分析未发现风险项。</p>\n"

    return HTML_TEMPLATE.format(
        target=_escape(target_url),
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        elapsed=elapsed,
        summary_section=summary,
        scan_section=scan_html,
        fingerprint_section=fp_html,
        analysis_section=analysis_html,
    )


def save_html(filepath: str, scan_results: list, fingerprint_info, content_findings,
              target_url: str, elapsed: float):
    """Save HTML report to file."""
    html = render_html(scan_results, fingerprint_info, content_findings, target_url, elapsed)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html)
    return filepath


def _escape(text: str) -> str:
    return (text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _format_size_html(size: int) -> str:
    if size == 0:
        return "—"
    if size < 1024:
        return f"{size}B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f}K"
    return f"{size / (1024 * 1024):.1f}M"
