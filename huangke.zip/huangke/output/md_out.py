"""Markdown 报告输出"""

from datetime import datetime

from ..core.scanner import ScanResult
from ..core.fingerprint import ServerInfo
from ..core.analyzer import ContentFinding


def export_markdown(scan_results: list,
                    fingerprint_info: ServerInfo | None,
                    content_findings: list,
                    target_url: str,
                    elapsed: float = 0) -> str:
    """导出扫描结果为 Markdown 字符串"""
    lines = []
    lines.append(f"# Aurox Toolkit 扫描报告\n")
    lines.append(f"**目标:** `{target_url}`  ")
    lines.append(f"**扫描时间:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  ")
    lines.append(f"**耗时:** {elapsed:.1f}s  ")
    lines.append("")

    # 总览
    lines.append("## 扫描总览\n")
    if scan_results:
        sev_counts = {}
        for r in scan_results:
            sev_counts[r.severity.label] = sev_counts.get(r.severity.label, 0) + 1
        lines.append(f"| 风险等级 | 数量 |")
        lines.append(f"|---------|------|")
        for label in ["严重", "高危", "中危", "低危", "信息"]:
            count = sev_counts.get(label, 0)
            if count:
                lines.append(f"| {label} | {count} |")
        lines.append("")

    # 指纹
    if fingerprint_info:
        lines.append("## 网站指纹\n")
        if fingerprint_info.server:
            lines.append(f"- **服务器:** {fingerprint_info.server}")
        if fingerprint_info.powered_by:
            lines.append(f"- **运行环境:** {fingerprint_info.powered_by}")
        if fingerprint_info.generator:
            lines.append(f"- **CMS/生成器:** {fingerprint_info.generator}")
        if fingerprint_info.page_title:
            lines.append(f"- **网站标题:** {fingerprint_info.page_title}")
        if fingerprint_info.ip:
            lines.append(f"- **IP 地址:** {fingerprint_info.ip}")
        lines.append("")

        if fingerprint_info.technologies:
            lines.append("### 识别的技术栈\n")
            lines.append("| 分类 | 名称 | 置信度 | 证据 |")
            lines.append("|------|------|--------|------|")
            for t in fingerprint_info.technologies:
                conf_cn = {"high": "高", "medium": "中", "low": "低"}.get(t.confidence, "低")
                lines.append(f"| {t.category} | {t.name} | {conf_cn} | {t.evidence[:60]} |")
            lines.append("")

        if getattr(fingerprint_info, "cdn", []):
            lines.append("### CDN / 加速节点\n")
            lines.append("| 提供商 | 证据 |")
            lines.append("|--------|------|")
            for c in fingerprint_info.cdn:
                lines.append(f"| {c.name} | {c.evidence} |")
            lines.append("")

        if fingerprint_info.waf:
            lines.append("### WAF 检测\n")
            lines.append("| 名称 | 证据 |")
            lines.append("|------|------|")
            for w in fingerprint_info.waf:
                lines.append(f"| {w.name} | {w.evidence} |")
            lines.append("")

        if fingerprint_info.security_headers:
            lines.append("### 安全响应头\n")
            lines.append("| 响应头 | 状态 |")
            lines.append("|--------|------|")
            for h, v in fingerprint_info.security_headers.items():
                status = "❌ 缺失" if v == "MISSING" else f"✅ {v[:60]}"
                lines.append(f"| {h} | {status} |")
            lines.append("")

    # 目录扫描
    if scan_results:
        lines.append("## 发现的端点\n")
        lines.append("| 路径 | 状态码 | 类型 | 大小 | 风险 | 说明 |")
        lines.append("|------|--------|------|------|------|------|")
        for r in sorted(scan_results, key=lambda x: x.severity.score, reverse=True):
            lines.append(
                f"| `{r.path}` | {r.status} | {r.content_type[:30] if r.content_type else '—'} | "
                f"{_fmt_size(r.content_length)} | {r.severity.label} | {r.risk_desc[:50]} |"
            )
        lines.append("")

    # 内容分析
    if content_findings:
        lines.append("## 内容分析发现\n")
        lines.append("| 风险 | 类型 | 详情 | 位置 |")
        lines.append("|------|------|------|------|")
        for f in sorted(content_findings, key=lambda x: x.severity.score, reverse=True):
            lines.append(
                f"| {f.severity.label} | {f.finding_type} | {f.detail[:50]} | `{f.url[:40]}` |"
            )
        lines.append("")

    lines.append("---")
    lines.append("*Aurox Toolkit v2.0 — 仅供授权安全测试使用*")
    return "\n".join(lines)


def save_markdown(filepath: str, scan_results: list, fingerprint_info, content_findings,
                  target_url: str, elapsed: float = 0):
    """保存 Markdown 报告到文件"""
    data = export_markdown(scan_results, fingerprint_info, content_findings, target_url, elapsed)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(data)
    return filepath


def _fmt_size(size: int) -> str:
    if size == 0:
        return "—"
    if size < 1024:
        return f"{size}B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f}K"
    return f"{size / (1024 * 1024):.1f}M"
