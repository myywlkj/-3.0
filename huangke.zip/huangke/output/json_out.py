"""JSON output formatter."""

import json
from datetime import datetime

from ..core.scanner import ScanResult
from ..core.fingerprint import ServerInfo
from ..core.analyzer import ContentFinding


def export_json(scan_results: list[ScanResult],
                fingerprint_info: ServerInfo | None,
                content_findings: list[ContentFinding],
                target_url: str,
                elapsed: float) -> str:
    """Export scan results to JSON string."""

    output = {
        "metadata": {
            "target": target_url,
            "timestamp": datetime.now().isoformat(),
            "elapsed_seconds": round(elapsed, 2),
            "tool": "Aurox Toolkit v1.0",
        },
        "scan_results": [
            {
                "path": r.path,
                "url": r.url,
                "status": r.status,
                "content_type": r.content_type,
                "content_length": r.content_length,
                "elapsed": round(r.elapsed, 3),
                "severity": r.severity.label,
                "risk_description": r.risk_desc,
                "body_preview": r.body_preview[:300] if r.body_preview else "",
            }
            for r in sorted(scan_results, key=lambda x: x.severity.score, reverse=True)
        ],
        "fingerprint": None,
        "content_analysis": [
            {
                "type": f.finding_type,
                "detail": f.detail,
                "severity": f.severity.label,
                "url": f.url,
                "context": f.context[:200] if f.context else "",
            }
            for f in content_findings
        ],
    }

    if fingerprint_info:
        output["fingerprint"] = {
            "server": fingerprint_info.server,
            "powered_by": fingerprint_info.powered_by,
            "generator": fingerprint_info.generator,
            "technologies": [
                {"category": t.category, "name": t.name, "evidence": t.evidence, "confidence": t.confidence}
                for t in fingerprint_info.technologies
            ],
            "waf": [
                {"name": w.name, "evidence": w.evidence}
                for w in fingerprint_info.waf
            ],
            "cdn": [
                {"name": c.name, "evidence": c.evidence}
                for c in getattr(fingerprint_info, "cdn", [])
            ],
            "security_headers": fingerprint_info.security_headers,
            "cookies": fingerprint_info.cookies,
        }

    return json.dumps(output, indent=2, ensure_ascii=False)


def save_json(filepath: str, scan_results: list, fingerprint_info, content_findings,
              target_url: str, elapsed: float):
    """Export scan results to a JSON file."""
    data = export_json(scan_results, fingerprint_info, content_findings, target_url, elapsed)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(data)
    return filepath
