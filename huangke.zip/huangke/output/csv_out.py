"""CSV 报告输出"""

import csv
import io
from datetime import datetime

from ..core.scanner import ScanResult
from ..core.fingerprint import ServerInfo
from ..core.analyzer import ContentFinding


def export_csv(scan_results: list,
               fingerprint_info: ServerInfo | None,
               content_findings: list,
               target_url: str) -> str:
    """导出扫描结果为 CSV 字符串"""
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["# Aurox Toolkit v2.0 扫描报告"])
    writer.writerow([f"# 目标: {target_url}"])
    writer.writerow([f"# 时间: {datetime.now().isoformat()}"])
    writer.writerow([])

    # 目录扫描结果
    writer.writerow(["目录扫描结果"])
    writer.writerow(["路径", "URL", "状态码", "类型", "大小", "风险等级", "说明"])
    for r in sorted(scan_results, key=lambda x: x.severity.score, reverse=True):
        writer.writerow([
            r.path, r.url, r.status,
            r.content_type[:60] if r.content_type else "",
            r.content_length,
            r.severity.label, r.risk_desc,
        ])
    writer.writerow([])

    # 指纹识别
    if fingerprint_info:
        writer.writerow(["指纹识别"])
        writer.writerow(["分类", "名称", "置信度", "证据"])
        for t in fingerprint_info.technologies:
            conf_cn = {"high": "高", "medium": "中", "low": "低"}.get(t.confidence, "低")
            writer.writerow([t.category, t.name, conf_cn, t.evidence])

        if fingerprint_info.waf:
            writer.writerow([])
            writer.writerow(["WAF 检测"])
            writer.writerow(["名称", "证据"])
            for w in fingerprint_info.waf:
                writer.writerow([w.name, w.evidence])

        if getattr(fingerprint_info, "cdn", []):
            writer.writerow([])
            writer.writerow(["CDN 检测"])
            writer.writerow(["提供商", "证据"])
            for c in fingerprint_info.cdn:
                writer.writerow([c.name, c.evidence])

        writer.writerow([])

    # 内容分析
    if content_findings:
        writer.writerow(["内容分析"])
        writer.writerow(["类型", "详情", "风险等级", "URL"])
        for f in sorted(content_findings, key=lambda x: x.severity.score, reverse=True):
            writer.writerow([f.finding_type, f.detail, f.severity.label, f.url])

    return buf.getvalue()


def save_csv(filepath: str, scan_results: list, fingerprint_info, content_findings,
             target_url: str, elapsed: float = 0):
    """保存 CSV 报告到文件"""
    data = export_csv(scan_results, fingerprint_info, content_findings, target_url)
    with open(filepath, "w", encoding="utf-8-sig", newline="") as f:
        f.write(data)
    return filepath
